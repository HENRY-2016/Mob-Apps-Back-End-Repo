<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DoorMatsModel extends Model
{
    // define table name
    use HasFactory;
    protected $table = 'DoorMats_table';
    protected $guarded = array();
}
