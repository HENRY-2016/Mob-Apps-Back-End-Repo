<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


class CarpetsModel extends Model
{
    // define table name
    use HasFactory;
    protected $table = 'Carpets_table';
    protected $guarded = array();
}
