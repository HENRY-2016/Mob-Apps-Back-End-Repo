<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BlackFridayModel extends Model
{
    // define table name
    use HasFactory;
    protected $table = 'blackfriday_table';
    protected $guarded = array();
}
