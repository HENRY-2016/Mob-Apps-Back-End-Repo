<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BabiesModel extends Model
{
    use HasFactory;
    protected $table = 'Babies_table';
    protected $guarded = array();
}
