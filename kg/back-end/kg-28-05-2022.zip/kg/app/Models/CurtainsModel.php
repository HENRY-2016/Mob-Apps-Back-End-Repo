<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CurtainsModel extends Model
{
    // define table name
    use HasFactory;
    protected $table = 'Curtains_table';
    protected $guarded = array();
}
