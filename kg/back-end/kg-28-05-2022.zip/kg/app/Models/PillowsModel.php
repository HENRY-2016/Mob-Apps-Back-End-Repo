<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PillowsModel extends Model
{
    // define table name
    use HasFactory;
    protected $table = 'Pillows_table';
    protected $guarded = array();
}
