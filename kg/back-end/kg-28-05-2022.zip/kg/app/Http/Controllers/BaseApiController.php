<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

// 32 models
use App\Models\BlackFridayModel; // our model
use App\Models\CustomersModel; // our model
use App\Models\OffersModel; // our model
use App\Models\OrdersModel; // our model
use App\Models\AboutModel; // our model
use App\Models\BathRobsModel; // our model
use App\Models\BathRoomModel; // our model
use App\Models\BedCoversModel; // our model
use App\Models\BedSheetsModel; // our model
use App\Models\BedSidesModel; // our model
use App\Models\BedsModel; // our model
use App\Models\BlanketsModel; // our model
use App\Models\CarpetsModel; // our model
use App\Models\ClosetModel; // our model
use App\Models\CurtainsModel; // our model
use App\Models\CussionsModel; // our model
use App\Models\DoorMatsModel; // our model
use App\Models\HomeModel; // our model
use App\Models\IroningBoardModel; // our model
use App\Models\MattressModel; // our model
use App\Models\MattressProtectorsModel; // our model
use App\Models\MirrorsModel; // our model
use App\Models\NetsModel; // our model
use App\Models\NightWareModel; // our model
use App\Models\PillowsModel; // our model
use App\Models\SandalsModel; // our model
use App\Models\SeatsModel; // our model
use App\Models\ShoeRackModel; // our model
use App\Models\SideBoardsModel; // our model
use App\Models\SliderModel; // our model
use App\Models\TablesModel; // our model
use App\Models\TowelsModel; // our model
use App\Models\BathroomCurtainsModel;
use App\Models\BabiesModel; // our model
// use App\Models\PaymentsModel; // our model



class BaseApiController extends Controller
{

    function listAllDashboardGooglePlayAppStatics ()
    {
        $results = array();
        $TotalAppInstalls = 951;
        $TotalAppUninstalls = 312;
        $CurrentAppDeviceInstalls =  690; 
        //$TotalAppInstalls - $TotalAppUninstalls;

        $results[] = array( "Installs"=> $TotalAppInstalls, "Uninstalls"=> $TotalAppUninstalls,"Devices"=>$CurrentAppDeviceInstalls);
        // echo $TotalAppUninstalls;
        return json_encode($results);
    }

    // List Products
    function listAllAbout (){return AboutModel::all();}
    function listAllSlider (){return SliderModel::all();}
    function listAllBabies (){return BabiesModel::all();}
    function listAllOffersProducts (){return OffersModel::all();}
    function listAllHomeProducts (){return HomeModel::all();}
    function listAllBlackFridayProducts (){return BlackFridayModel::all();}


    // Bed Room
    function listAllBedRoomBedsProducts (){return BedsModel::all();}
    function listAllBedRoomNetsProducts (){return NetsModel::all();}
    function listAllBedRoomBedCoversProducts (){return BedCoversModel::all();}
    function listAllBedRoomPillowsProducts (){return PillowsModel::all();}
    function listAllBedRoomClosetProducts (){return ClosetModel::all();}
    function listAllBedRoomCussionsProducts (){return CussionsModel::all();}
    function listAllBedRoomShoeRackProducts (){return ShoeRackModel::all();}
    function listAllBedRoomBedSheetsProducts (){return BedSheetsModel::all();}
    function listAllBedRoomBlanketsProducts (){return BlanketsModel::all();}
    function listAllBedRoomMattressProducts (){return MattressModel::all();}
    function listAllBedRoomMattressProtectorsProducts (){return MattressProtectorsModel::all();}
    function listAllBedRoomSandalsProducts (){return SandalsModel::all();}
    function listAllBedRoomBedSidesProducts (){return BedSidesModel::all();}
    function listAllBedRoomMirrorsProducts (){return MirrorsModel::all();}
    function listAllBedRoomNightWareProducts (){return NightWareModel::all();}

    // Living Room
    function listAllLivingRoomCurtainsProducts (){return CurtainsModel::all();}
    function listAllLivingRoomSeatsProducts (){return SeatsModel::all();}
    function listAllLivingRoomSideBoardsProducts (){return SideBoardsModel::all();}
    function listAllLivingRoomTablesProducts (){return TablesModel::all();}
    function listAllLivingRoomCarpetsProducts (){return CarpetsModel::all();}
    function listAllLivingRoomIroningBoardProducts (){return IroningBoardModel::all();}

    // BathRoom
    function listAllBathRoomBathRobsProducts (){return BathRobsModel::all();}
    function listAllBathRoomTowelsProducts (){return TowelsModel::all();}
    function listAllBathRoomCurtainsProducts (){return BathroomCurtainsModel::all();}
    function listAllBathRoomDoorMatsProducts (){return DoorMatsModel::all();}

    // post request
    function createCustomer (Request $request)
    {
        // echo $request;
        $newuser = new CustomersModel();
        $newuser -> Name = $request-> Name;
        $newuser -> Phone = $request -> Phone;
        $newuser -> Email = $request -> Email;
        $newuser -> Password = $request -> Password;


        if ($newuser -> save())
        {
            return ['status'=>  'Account Has Been Created'];
        }
    }
    function customerLogin ($phone)
    {
        // https://laravel.su/docs/5.5/queries
        $data = CustomersModel::where('Phone',$phone)->first();
        return compact('data');
    }
    function listAllCustomerOrderDetailsByAdmin ($id)
    {
        $data = OrdersModel::where('id',$id)->first();
        return compact('data');

    }
    function listAllCustomerOrders ($phone)
    {
        $data = OrdersModel::where('phone',$phone)->get(['id','Phone','Reference','DeliveryMethod','Status','PaymentMethod','created_at']);
        return json_encode($data);
    }

    //===================================================
    //
    // Orders View
    //
    //===================================================
    function listAllNewOrders ()
    {
        $today = date("d-m-Y");
        $data = OrdersModel::where('PalaceHolderOne',$today)->get(['id','Phone','Amount','PalaceHolderOne','PalaceHolderTwo','Status','Reference','DeliveryMethod','Status','PaymentMethod']);
        return json_encode($data);
    }
    function listAllPendingOrders ()
    {
        $paymentStatus = "NotCleared";
        $data = OrdersModel::where('PalaceHolderTwo',$paymentStatus)->get(['id','Phone','Amount','PalaceHolderOne','PalaceHolderTwo','Status','Reference','DeliveryMethod','Status','PaymentMethod']);
        return json_encode($data);
    }
    function listAllClearedOrders ()
    {
        $paymentStatus = "Cleared";
        $data = OrdersModel::where('PalaceHolderFour',$paymentStatus)->get(['id','Phone','Amount','PalaceHolderOne','PalaceHolderTwo','Status','Reference','DeliveryMethod','Status','PaymentMethod']);
        return json_encode($data);
    }
    //===================================================
    //
    // Payments View
    //
    //===================================================

    function listAllClearedOrderPayments ()
    {
        $paymentStatus = "Cleared";
        $data = OrdersModel::where('PalaceHolderFour',$paymentStatus)->get(['Phone','Amount','Reference','PalaceHolderOne','PalaceHolderTwo','PalaceHolderThree','PalaceHolderFive']);
        // $data = OrdersModel::all();
        return json_encode($data);
    }
    function listAllNotClearedOrderPayments ()
    {
        $paymentStatus = "NotCleared";
        $data = OrdersModel::where('PalaceHolderTwo',$paymentStatus)->get(['Phone','Amount','Reference','PalaceHolderOne','PalaceHolderTwo','PalaceHolderThree','PalaceHolderFive']);
        return json_encode($data);
    }
    function listAllNewPayments ()
    {
        $today = date("Y-m-d");
        $data = OrdersModel::where('PalaceHolderFive',$today)->get(['Phone','Amount','Reference','PalaceHolderOne','PalaceHolderTwo','PalaceHolderThree','PalaceHolderFive']);
        return json_encode($data);
    }
    function listAllFullPayments ()
    {
        $paymentStatus = "Full Payment";
        $data = OrdersModel::where('PalaceHolderTwo',$paymentStatus)->get(['Phone','Amount','Reference','PalaceHolderOne','PalaceHolderTwo','PalaceHolderThree','PalaceHolderFive']);
        return json_encode($data);
    }
    function listAllHalfPayments ()
    {
        $paymentStatus = "Half Payment";
        $data = OrdersModel::where('PalaceHolderTwo',$paymentStatus)->get(['Phone','Amount','Reference','PalaceHolderOne','PalaceHolderTwo','PalaceHolderThree','PalaceHolderFive']);
        return json_encode($data);
    }




    function listCustomerOrderListArray ($id)
    {

        $data = OrdersModel::where('id',$id)->get(['OrderListArray']);
        $str1 = substr($data, 22); // removes fisrt 22 chars from a string
        $str2 = substr($str1,0,-5); // removes last 5 chars from a string
        $results = str_replace('\\', '', $str2);// removes Backslash from a string

        return $results;

    }

    function newCustomerOrder (Request $request)
    {
        // PalaceHolderOne == order date
        // PalaceHolderTwo == half or full payments
        // PalaceHolderThree == customer amount
        // PalaceHolderFour == payments status
        // PalaceHolderFive == payment date

        $amount ="None";
        $date = date("d-m-Y");
        $palaceHolderTwo = " ";
        $Status = "Pending";
        $Address = "";
        $Name=" ";


        $neworder = new OrdersModel();
        $neworder-> Name = $Name;
        $neworder-> Phone = $request-> Phone;
        $neworder-> Address = $Address;
        $neworder-> Reference = $request->Reference;
        $neworder-> Amount = $request-> Amount;
        $neworder-> Status = $Status;
        $neworder-> DeliveryMethod = $request->DeliveryMethod;
        $neworder-> PaymentMethod = $request-> PaymentMethod;
        $neworder-> PalaceHolderOne = $date;
        $neworder-> PalaceHolderTwo = "NotCleared";
        $neworder-> PalaceHolderThree = $amount;
        $neworder-> PalaceHolderFour = $palaceHolderTwo;
        $neworder-> PalaceHolderFive = $palaceHolderTwo;
        $neworder-> PalaceHolderSix = $palaceHolderTwo;
        $neworder-> PalaceHolderSeven = $palaceHolderTwo;
        $neworder-> PalaceHolderEight = $palaceHolderTwo;
        $neworder-> PalaceHolderNine = $palaceHolderTwo;
        $neworder-> PalaceHolderTen = $palaceHolderTwo;

        $Orderlist = $request-> OrderListArray;
        $customerOrderList = json_encode($Orderlist);
        $neworder -> OrderListArray = $customerOrderList;


        if ($neworder -> save())
            {return ['status'=>'Your Order Has Been  Received Process Your Payments'];}
        else
            {return ['status'=>'Order Not Received Try Again '];}
    }


// ==============================================================
//
//  Dashboard Orders Api
//
// ==============================================================
    function listAllDashboardClearedOrderPayments ()
    {
        $paymentStatus = "Cleared";
        $data = OrdersModel::where('PalaceHolderFour',$paymentStatus)->get(['Amount']);
        return json_encode($data);
    }
    function listAllDashboardNotClearedOrderPayments ()
    {
        $paymentStatus = "NotCleared";
        $data = OrdersModel::where('PalaceHolderTwo',$paymentStatus)->get(['Amount']);
        return json_encode($data);
    }
    function listAllDashboardNewOrders ()
    {
        $today = date("d-m-Y");
        $data = OrdersModel::where('PalaceHolderOne',$today)->get(['Amount']);
        return json_encode($data);
    }
    function listAllDashboardTotalOrders ()
    {
        $data = OrdersModel::get(['Amount']);
        return json_encode($data);
    }




// ==============================================================
//
//  Dashboard Orders Api
//
// ==============================================================
function listAllDashboardNewPayments ()
{
    $today = date("Y-m-d");
    $data = OrdersModel::where('PalaceHolderFive',$today)->get(['PalaceHolderThree']);
    return json_encode($data);
}
function listAllDashboardPendingPayments ()
{
    $paymentStatus = "NotCleared";
    $data = OrdersModel::where('PalaceHolderTwo',$paymentStatus)->get(['Amount']);
    return json_encode($data);
}
function listAllDashboardHalfPayments ()
{
    $paymentStatus = "Half Payment";
    $data = OrdersModel::where('PalaceHolderTwo',$paymentStatus)->get(['PalaceHolderThree']);
    return json_encode($data);
}

function listAllDashboardFullPayments ()
{
    $paymentStatus = "Full Payment";
    $data = OrdersModel::where('PalaceHolderTwo',$paymentStatus)->get(['PalaceHolderThree']);
    return json_encode($data);
}
function listAllDashboardTotalPayments ()
{
    $paymentStatus = "Cleared";
    $data = OrdersModel::where('PalaceHolderFour',$paymentStatus)->get(['PalaceHolderThree']);
    return json_encode($data);
}


}
