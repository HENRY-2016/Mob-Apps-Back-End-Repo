<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\AboutModel; // our model

class AboutController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = AboutModel::latest () -> paginate(10);
        return view('about/view', compact('data'))
                -> with('i',(request()->input('page',1)-1)*12); // for pagination
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request -> validate ([
            'About' => 'required',
            'AboutShop'  => 'required',
            'Location'  => 'required',
            'Motto'  => 'required',
            'OtherOne'  => 'required',
            'OtherTwo'  => 'required',
            'OtherThree'  => 'required',
            'Bank1Names'  => 'required',
            'Bank2Names'  => 'required',
            'Bank1'  => 'required',
            'Bank2'  => 'required',
            'Tell2Names'  => 'required',
            'Tell1Names'  => 'required',
            'Tell1'  => 'required',
            'Tell2'  => 'required',
            'AccBank1Names'=> 'required',
            'AccBank2Names'=> 'required',

        ]);

        // insert Data
        $form_data = array(
            'About' => $request-> About,
            'AboutShop'  => $request-> AboutShop,
            'Location'  => $request-> Location,
            'Motto'  => $request-> Motto,
            'OtherOne'  => $request-> OtherOne,
            'OtherTwo'  => $request->OtherTwo,
            'OtherThree'  => $request-> OtherThree,


            'Bank1Names'  => $request->Bank1Names,
            'Bank2Names'  => $request->Bank2Names,
            'Bank1'  => $request->Bank1,
            'Bank2'  => $request->Bank2,
            'Tell2Names'  => $request->Tell2Names,
            'Tell1Names'  => $request->Tell1Names,
            'Tell1'  => $request->Tell1,
            'Tell2'  => $request->Tell2,

            'PalaceHolderOne' => $request->AccBank1Names,
            'PalaceHolderTwo' => $request->AccBank2Names,
            'PalaceHolderThree' => "Empty",
            'PalaceHolderFour'=> "Empty",
            'PalaceHolderFive'=> "Empty",
            'PalaceHolderSix'=> "Empty",
            'PalaceHolderSeven'=> "Empty",
            'PalaceHolderEight'=> "Empty",
            'PalaceHolderNine'=> "Empty",
            'PalaceHolderTen'=> "Empty",

        );
        AboutModel::create ($form_data);
        return redirect('aboutcrud')
            ->with('success','Data Added successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $data = AboutModel::findOrFail($id);
        return view('about/details', compact('data'));
        // echo $data;
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = AboutModel::findOrFail($id);
        return view('about/edit', compact('data'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request -> validate ([
            'About' => 'required',
            'AboutShop'  => 'required',
            'Location'  => 'required',
            'Motto'  => 'required',
            'OtherOne'  => 'required',
            'OtherTwo'  => 'required',
            'OtherThree'  => 'required',

            'Bank1Names'  => 'required',
            'Bank2Names'  => 'required',
            'Bank1'  => 'required',
            'Bank2'  => 'required',
            'Tell2Names'  => 'required',
            'Tell1Names'  => 'required',
            'Tell1'  => 'required',
            'Tell2'  => 'required',
            'AccBank1Names'=> 'required',
            'AccBank2Names'=> 'required',


        ]);
        // Update Data
        $form_data = array(
            'About' => $request-> About,
            'AboutShop'  => $request-> AboutShop,
            'Location'  => $request-> Location,
            'Motto'  => $request-> Motto,
            'OtherOne'  => $request-> OtherOne,
            'OtherTwo'  => $request->OtherTwo,
            'OtherThree'  => $request-> OtherThree,



            'Bank1Names'  => $request->Bank1Names,
            'Bank2Names'  => $request->Bank2Names,
            'Bank1'  => $request->Bank1,
            'Bank2'  => $request->Bank2,
            'Tell2Names'  => $request->Tell2Names,
            'Tell1Names'  => $request->Tell1Names,
            'Tell1'  => $request->Tell1,
            'Tell2'  => $request->Tell2,
            'PalaceHolderOne' => $request->AccBank1Names,
            'PalaceHolderTwo' => $request->AccBank2Names,
            'PalaceHolderThree' => "Empty",
            'PalaceHolderFour'=> "Empty",
            'PalaceHolderFive'=> "Empty",
            'PalaceHolderSix'=> "Empty",
            'PalaceHolderSeven'=> "Empty",
            'PalaceHolderEight'=> "Empty",
            'PalaceHolderNine'=> "Empty",
            'PalaceHolderTen'=> "Empty",

        );
        // update
        AboutModel::whereId ($id)->update($form_data);
        return redirect('aboutcrud')
            ->with('success','Data Is Successfully Updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
         // delete
        $data = AboutModel::findOrFail($id);
        $data ->delete();
        return redirect('aboutcrud')
            ->with('success','Data Is Successfully deleted');
    }
}
