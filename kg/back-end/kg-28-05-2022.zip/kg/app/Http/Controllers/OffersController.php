<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\OffersModel; // our model

class OffersController extends Controller
{
    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = OffersModel::latest () -> paginate(10);
        return view('offers/view', compact('data'))
                -> with('i',(request()->input('page',1)-1)*12); // for pagination
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request -> validate ([
            'Name' => 'required',
            'Description'  => 'required',
            'Amount'  => 'required',
            'image'  => 'required | image | max:2048',
            'Status'  => 'required',
            

        ]);
        $image = $request->file('image');
        $new_name = rand().'.'.$image->getClientOriginalExtension ();
        $image ->move(public_path('images'),$new_name);

        // insert Data
        $form_data = array(
            'Name' => $request->Name,
            'Description'  => $request->Description,
            'Amount'  => $request->Amount,
            'image'  => $new_name,

            'PalaceHolderOne' => $request->Status,
            'PalaceHolderTwo'  => "Empty",
            'PalaceHolderThree' => "Empty",
            'PalaceHolderFour'=> "Empty",
            'PalaceHolderFive'=> "Empty",
            'PalaceHolderSix'=> "Empty",
            'PalaceHolderSeven'=> "Empty",
            'PalaceHolderEight'=> "Empty",
            'PalaceHolderNine'=> "Empty",
            'PalaceHolderTen'=> "Empty",
            'PalaceHolder11'=> "Empty",
            'PalaceHolder12'=> "Empty",
            'PalaceHolder13'=> "Empty",
            'PalaceHolder14'=> "Empty",
            'PalaceHolder15'=> "Empty",

        );
        OffersModel::create ($form_data);
        return redirect('offerscrud')
            ->with('success','Data Added successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $data = OffersModel::findOrFail($id);
        return view('offers/details', compact('data'));
        // echo $data;
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = OffersModel::findOrFail($id);
        return view('offers/edit', compact('data'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $image_name = $request->hidden_image;
        $image = $request->file('image');
        if ($image !='')
        {
            $request -> validate ([
                'Name' => 'required',
                'Description'  => 'required',
                'Amount'  => 'required',
                'image'  => 'image | max:2048',
                'Status'  => 'required',
            ]);

            // defin new img name
            $image_name = rand().'.'.$image->getClientOriginalExtension ();
            $image->move(public_path('images'),$image_name);
        }
        else
        {
            $request -> validate ([
                'Name' => 'required',
                'Description'  => 'required',
                'Amount'  => 'required',
                'Status'  => 'required',
            ]);

        }
        // Update Data
        $form_data = array(
            'Name' => $request->Name,
            'Description'  => $request->Description,
            'Amount'  => $request->Amount,
            'image'  => $image_name,

            'PalaceHolderOne' => $request->Status,
            'PalaceHolderTwo'  => "Empty",
            'PalaceHolderThree' => "Empty",
            'PalaceHolderFour'=> "Empty",
            'PalaceHolderFive'=> "Empty",
            'PalaceHolderSix'=> "Empty",
            'PalaceHolderSeven'=> "Empty",
            'PalaceHolderEight'=> "Empty",
            'PalaceHolderNine'=> "Empty",
            'PalaceHolderTen'=> "Empty",
            'PalaceHolder11'=> "Empty",
            'PalaceHolder12'=> "Empty",
            'PalaceHolder13'=> "Empty",
            'PalaceHolder14'=> "Empty",
            'PalaceHolder15'=> "Empty",
        );
        // update
        OffersModel::whereId ($id)->update($form_data);
        return redirect('offerscrud')
            ->with('success','Data Is Successfully Updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
         // delete
        $data = OffersModel::findOrFail($id);
        $data ->delete();
        return redirect('offerscrud')
            ->with('success','Data Is Successfully deleted');
    }
}
