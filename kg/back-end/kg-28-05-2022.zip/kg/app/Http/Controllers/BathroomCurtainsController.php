<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\BathroomCurtainsModel; // our model

class BathroomCurtainsController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = BathroomCurtainsModel::latest () -> paginate(10);
        return view('bathroom/bathroomcurtains/view', compact('data'))
                -> with('i',(request()->input('page',1)-1)*12); // for pagination
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request -> validate ([
            'Name' => 'required',
            'Description'  => 'required',
            'Amount'  => 'required',
            'image'  => 'required | image | max:2048'
        ]);
        $image = $request->file('image');
        $new_name = rand().'.'.$image->getClientOriginalExtension ();
        $image ->move(public_path('images'),$new_name);

        // insert Data
        $form_data = array(
            'Name' => $request->Name,
            'Description'  => $request->Description,
            'Amount'  => $request->Amount,
            'image'  => $new_name
        );
        BathroomCurtainsModel::create ($form_data);
        return redirect('bathroomcurtainscrud')
            ->with('success','Data Added successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $data = BathroomCurtainsModel::findOrFail($id);
        return view('bathroom/bathroomcurtains/details', compact('data'));
        // echo $data;
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = BathroomCurtainsModel::findOrFail($id);
        return view('bathroom/bathroomcurtains/edit', compact('data'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $image_name = $request->hidden_image;
        $image = $request->file('image');
        if ($image !='')
        {
            $request -> validate ([
                'Name' => 'required',
                'Description'  => 'required',
                'Amount'  => 'required',
                'image'  => 'image | max:2048'
            ]);

            // defin new img name
            $image_name = rand().'.'.$image->getClientOriginalExtension ();
            $image->move(public_path('images'),$image_name);
        }
        else
        {
            $request -> validate ([
                'Name' => 'required',
                'Description'  => 'required',
                'Amount'  => 'required',
            ]);

        }
        // Update Data
        $form_data = array(
            'Name' => $request->Name,
            'Description'  => $request->Description,
            'Amount'  => $request->Amount,
            'image'  => $image_name
        );
        // update
        BathroomCurtainsModel::whereId ($id)->update($form_data);
        return redirect('bathroomcurtainscrud')
            ->with('success','Data Is Successfully Updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
         // delete
        $data = BathroomCurtainsModel::findOrFail($id);
        $data ->delete();
        return redirect('bathroomcurtainscrud')
            ->with('success','Data Is Successfully deleted');
    }
}
