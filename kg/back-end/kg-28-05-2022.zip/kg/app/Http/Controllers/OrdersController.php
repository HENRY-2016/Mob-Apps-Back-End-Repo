<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\OrdersModel; 


class OrdersController extends Controller
{
    

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = OrdersModel::latest () -> paginate(10);
        return view('orders/view', compact('data'))
                -> with('i',(request()->input('page',1)-1)*12); // for pagination
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $data = OrdersModel::findOrFail($id);
        return view('orders/details', compact('data'));
        // echo $data;
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = OrdersModel::findOrFail($id);
        return view('orders/edit', compact('data'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        // PalaceHolderOne == order date
        // PalaceHolderTwo == half or full payments
        // PalaceHolderThree == customer amount
        // PalaceHolderFour == payments status
        // PalaceHolderFive == payments date

        // $request -> validate ([
        //     'Status' => 'required',
        //     'PalaceHolderTwo' => 'required',
        //     'PalaceHolderThree' => 'required',
        //     ]);


        $paymentStatus ="";
        $orderStatus = "";
        $halfOrFullStatus = "";
        $dateUpdate = "";

        $amountInput = trim($request->PalaceHolderThree);
        $currentOrderStatus = trim($request->Status1);
        $currentPaymentStatus = trim($request->PalaceHolderTwo1);
        $newOrderStatus = trim($request->Status);
        $newPaymentStatus = trim($request->PalaceHolderTwo);
        $currentDate = trim($request->PalaceHolderFive1);
        $newDate = trim($request->PalaceHolderFive);


        if ($amountInput == "None"){$paymentStatus ="NotCleared";}
        elseif ($amountInput != "None"){$paymentStatus = "Cleared";}

        if ($newOrderStatus == "Empty"){$orderStatus = $currentOrderStatus;}
        elseif($newOrderStatus != "Empty"){$orderStatus = $newOrderStatus;}

        if ($newPaymentStatus == "Empty"){$halfOrFullStatus = $currentPaymentStatus;}
        elseif($newPaymentStatus != "Empty"){$halfOrFullStatus = $newPaymentStatus;}

        if ($newDate == ""){$dateUpdate = $currentDate;}
        elseif ($newDate != ""){$dateUpdate = $newDate;}


        // Update Data
        $form_data = array(
            'Status' => $orderStatus,
            'PalaceHolderTwo' => $halfOrFullStatus,
            'PalaceHolderThree' => $request->PalaceHolderThree,
            'PalaceHolderFour' => $paymentStatus,
            'PalaceHolderFive' => $dateUpdate,

        );
        // update
        OrdersModel::whereId ($id)->update($form_data);
        return redirect('orderscrud')
            ->with('success','Data Is Successfully Updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
         // delete
        $data = OrdersModel::findOrFail($id);
        $data ->delete();
        return redirect('orderscrud')
            ->with('success','Data Is Successfully deleted');
    }
}
