
// var baseUrl = "http://176.58.115.77:5050";
var baseUrl = "http://127.0.0.1:8000";

// orders
var APIorderdetails = baseUrl+"/api/orders/list/customer/order/details/by/admin/by/id/";
var APIListNewOrders =  baseUrl+"/api/orders/list/all/new/orders";
var APIListPendingOrders =  baseUrl+"/api/orders/list/all/pending/orders";
var APIListClearedOrders =  baseUrl+"/api/orders/list/all/cleared/orders";

// payments
var APIListClearedPayments =  baseUrl+"/api/payments/list/all/cleared";
var APIListNotClearedPayments =  baseUrl+"/api/payments/list/all/not/cleared";
var APIListNewPayments =  baseUrl+"/api/payments/list/all/new/payment";
var APIListFullPayments =  baseUrl+"/api/payments/list/all/full/payment";
var APIListHalfPayments =  baseUrl+"/api/payments/list/all/half/payment";



// dashboard orders
var APIListDashboardClearedPayments = baseUrl+"/api/dashboard/list/all/cleared/order/payments";
var APIListDashboardNotClearedPayments = baseUrl+"/api/dashboard/list/all/not/cleared/order/payments";
var APIListDashboardNewOrders = baseUrl+"/api/dashboard/list/all/new/orders";
var APIListDashboardTotalOrders = baseUrl+"/api/dashboard/list/all/total/orders";

// dashboard payments
var APIListDashboardNewPayments = baseUrl+"/api/dashboard/list/all/new/payments";
var APIListDashboardPendingPayments = baseUrl+"/api/dashboard/list/all/pending/payments";
var APIListDashboardHalfPayments = baseUrl+"/api/dashboard/list/all/half/payments";
var APIListDashboardFullPayments = baseUrl+"/api/dashboard/list/all/full/payments";
var APIListDashboardTotalPayments = baseUrl+"/api/dashboard/list/all/total/payments";



var APIImages = baseUrl+"/images/";

function OloadInitiApplication ()
{
    display_Date ();
    LogInUser();
}
function display_Date ()
{

    let today = new Date();
    let date = today.getDate()+'/'+(today.getMonth()+1)+'/ '+today.getFullYear() ;
    let time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    const weekday = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
    let day = weekday[today.getDay()];

    date_and_time = day+ " " +date+" " + " "+time;
    document.getElementById('date-span').innerText = date_and_time;
}


function Log_InPage (){window.location= baseUrl+"/login"}
function LogInUser ()
{
    // get uer credentials
    username = localStorage.getItem("username");

    if (username)
    {
        // usernameinput.value = username

    }
    else{Log_InPage();}
}
function Log_Out_User ()
{

    localStorage.removeItem("username");
    Log_InPage ();
}

////////////////////////////////////////////// laravel /////////////////
function Show_Customer_Order_Details (id)
{
    document.getElementById("orderlist-table-view-div").style.display="none";
    document.getElementById("orderlist-details-view-div").style.display="block";
    $.ajax({
            url:APIorderdetails+id,
            type:'get',
            dataType:'JSON',
            error: function ()
            {
                console.log("Request Unsuccessful")
            },
            success: function (response)
            {
                console.log(response.data.Status)

                let PaymentMethod = response.data.PaymentMethod;
                let DeliveryMethod = response.data.DeliveryMethod;
                let amount = response.data.Amount;
                let time = response.data.created_at.slice(0, 10);
                let Status = response.data.Status;
                let id = response.data.id;
                let phone = response.data.Phone;
                let ordernumber = response.data.Reference;
                let orderListArray = response.data.OrderListArray;

                let htmlstatus = document.getElementById("status");
                let htmlPhone = document.getElementById("phone");
                let htmlDeliveryMethod = document.getElementById("DeliveryMethod");
                let htmlOrdernumber = document.getElementById("ordernumber");
                let htmlPaymentMethod = document.getElementById("PaymentMethod");
                let htmlAmount = document.getElementById("amount");
                let htmlTime = document.getElementById("time");
                let htmlOrderList = document.getElementById("order");
                let formated_Orderlist =  orderListArray.replace(/\\/g, '');

                htmlstatus.innerText = Status;
                htmlPhone.innerText = phone;
                htmlDeliveryMethod .innerText = DeliveryMethod;
                htmlOrdernumber.innerText = ordernumber;
                htmlPaymentMethod.innerText =PaymentMethod;
                htmlAmount.innerText =amount;
                htmlTime.innerText =time;
                // htmlOrderList.innerText = formated_Orderlist;


                let parentDiv = document.getElementById('mycard');
                let list = formated_Orderlist.slice(1, -1);
                let jsonList= JSON.parse(list);
                console.log(jsonList);
                // console.log(list2[0].name);

                for (i=0; i<jsonList.length; i++)
                {
                    let namelabel = document.createElement("Label");
                    let statuslabel = document.createElement("Label");
                    let amountlabel = document.createElement("Label");
                    let qtylabel = document.createElement("Label");
                    let brlabel = document.createElement("Label");
                    let image = document.createElement("img");


                    image.setAttribute("class","listImage");
                    namelabel.setAttribute("class","namelistlabels");
                    statuslabel.setAttribute("class","listlabels");
                    amountlabel.setAttribute("class","listlabels");
                    qtylabel.setAttribute("class","listlabels");



                    // asign values
                    namelabel.innerHTML ="Name :: "+jsonList[i].name+"<br>";
                    statuslabel.innerHTML ="Size :: "+jsonList[i].status+"<br>";
                    amountlabel.innerHTML ="Amount :: "+jsonList[i].amount+"<br>";
                    qtylabel.innerHTML = "Qty :: "+jsonList[i].qty +"<br><br>";
                    image.src= APIImages+jsonList[i].image
                    brlabel.innerHTML ="<br><br><br>"

                    image.appendChild(brlabel);
                    qtylabel.appendChild(image);
                    amountlabel.appendChild(qtylabel);
                    statuslabel.appendChild(amountlabel);
                    namelabel.appendChild(statuslabel);
                    parentDiv.appendChild(namelabel);

                }

            }
            });
}

function Show_Cleared_Customer_Payments_Details (APICall)
{
    $.ajax({
            url:APICall,
            type:'get',
            dataType:'JSON',
            error: function ()
            {
                console.log("Request Unsuccessful")
            },
            success: function (response)
            {

                let thead = '<tr class="table-thead">'+
                            '<th class="table-thead-th">'+'Customer'+'</th>'+
                            '<th class="table-thead-th">'+'Order Date'+'</th>'+
                            '<th class="table-thead-th">'+' Reference '+'</th>'+
                            '<th class="table-thead-th">'+'Order Amount'+'</th>'+
                            '<th class="table-thead-th">'+'Payment Status'+'</th>'+
                            '<th class="table-thead-th">'+'Payment Made'+'</th>'+
                            '<th class="table-thead-th">'+'PaymentDate'+'</th>'+


                            '</tr>';
                $('#html-table-id tbody').append(thead);

                let results = response
                for (i=0; i<results.length; i++)
                {
                    let Phone = response[i].Phone;
                    let OrderDate = response[i].PalaceHolderOne;
                    let Amount = response[i].Amount
                    let Reference = response[i].Reference;
                    let PaymentStatus = response[i].PalaceHolderTwo;
                    let AmountPaid = response[i].PalaceHolderThree;
                    let PaymentDate = response[i].PalaceHolderFive;


                    let tablerow = '<tr class="table-row">'+
                                        '<td class="table-row-td">'  +  Phone + "</td>" +
                                        '<td class="table-row-td">'  +  OrderDate + "</td>" +
                                        '<td class="table-row-td">'  +  Reference+ "</td>" +
                                        '<td class="table-row-td">'  +  Amount + "</td>" +
                                        '<td class="table-row-td">'  +  PaymentStatus + "</td>" +
                                        '<td class="table-row-td">'  +  AmountPaid + "</td>" +
                                        '<td class="table-row-td">'  +  PaymentDate + "</td>" +

                                    "</tr>"
                    $('#html-table-id tbody').append(tablerow);

                }

            }
            });
}


function Show_Not_Cleared_Customer_Payments_Details ()
{
    $.ajax({
            url:APIListNotClearedPayments,
            type:'get',
            dataType:'JSON',
            error: function ()
            {
                console.log("Request Unsuccessful")
            },
            success: function (response)
            {

                let thead = '<tr class="table-thead">'+
                            '<th class="table-thead-th">'+'Customer'+'</th>'+
                            '<th class="table-thead-th">'+'Order Date'+'</th>'+
                            '<th class="table-thead-th">'+' Reference '+'</th>'+
                            '<th class="table-thead-th">'+'Order Amount'+'</th>'+
                            '<th class="table-thead-th">'+'Payment Status'+'</th>'+

                            '</tr>';
                $('#html-table-id tbody').append(thead);

                let results = response
                for (i=0; i<results.length; i++)
                {
                    let Phone = response[i].Phone;
                    let OrderDate = response[i].PalaceHolderOne;
                    let Amount = response[i].Amount
                    let Reference = response[i].Reference;
                    let PaymentStatus = response[i].PalaceHolderTwo;


                    let tablerow = '<tr class="table-row">'+
                                        '<td class="table-row-td">'  +  Phone + "</td>" +
                                        '<td class="table-row-td">'  +  OrderDate + "</td>" +
                                        '<td class="table-row-td">'  +  Reference+ "</td>" +
                                        '<td class="table-row-td">'  +  Amount + "</td>" +
                                        '<td class="table-row-td">'  +  PaymentStatus + "</td>" +
                                    "</tr>"
                    $('#html-table-id tbody').append(tablerow);

                }

            }
            });
}



function Show_Dashboard_Orders_Status (APICall,CustomerId,AmountId)
{
    $.ajax({
            url:APICall,
            type:'get',
            dataType:'JSON',
            error: function ()
            {
                alert("Request Unsuccessful")
            },
            success: function (response)
            {
                let total = 0;
                let results = response;
                let customers = response.length;
                for (i=0; i<results.length; i++)
                {
                    let Amount = response[i].Amount;
                    let withoutCommas = Amount.replace(/,/g, '');
                    total += parseInt(withoutCommas);
                }
                document.getElementById(CustomerId).innerHTML = customers
                document.getElementById(AmountId).innerHTML = total.toLocaleString()
            }
            });
}
function Show_Dashboard_Payments_Status (APICall,CustomerId,AmountId)
{
    $.ajax({
            url:APICall,
            type:'get',
            dataType:'JSON',
            error: function ()
            {
                alert("Request Unsuccessful")
            },
            success: function (response)
            {
                let total = 0;
                let results = response;
                let customers = response.length;
                for (i=0; i<results.length; i++)
                {
                    let Amount = response[i].PalaceHolderThree;
                    let withoutCommas = Amount.replace(/,/g, '');
                    total += parseInt(withoutCommas);
                }
                document.getElementById(CustomerId).innerHTML = customers
                document.getElementById(AmountId).innerHTML = total.toLocaleString()
            }
            });
}


function Show_Orders_Details (APICall)
{
    $.ajax({
            url:APICall,
            type:'get',
            dataType:'JSON',
            error: function ()
            {
                console.log("Request Unsuccessful")
            },
            success: function (response)
            {

                let thead = '<tr class="table-thead">'+
                            '<th class="table-thead-th">'+'Customer'+'</th>'+
                            '<th class="table-thead-th">'+'Order Date'+'</th>'+
                            '<th class="table-thead-th">'+' Reference '+'</th>'+
                            '<th class="table-thead-th">'+'Order Amount'+'</th>'+
                            '<th class="table-thead-th">'+'Delivery Method'+'</th>'+
                            '<th class="table-thead-th">'+'Payment Method'+'</th>'+
                            '<th class="table-thead-th">'+'Payment Made'+'</th>'+
                            '<th class="table-thead-th">'+'Order Status'+'</th>'+



                            '</tr>';
                $('#html-table-id tbody').append(thead);

                let results = response
                for (i=0; i<results.length; i++)
                {
                    let Phone = response[i].Phone;
                    let OrderDate = response[i].PalaceHolderOne;
                    let Amount = response[i].Amount
                    let Reference = response[i].Reference;
                    let DeliveryMethod = response[i].DeliveryMethod;
                    let PaymentMethod = response[i].PaymentMethod;
                    let PaymentStatus = response[i].PalaceHolderTwo;
                    let OrderStatus = response[i].Status;



                    let tablerow = '<tr class="table-row">'+
                                        '<td class="table-row-td">'  +  Phone + "</td>" +
                                        '<td class="table-row-td">'  +  OrderDate + "</td>" +
                                        '<td class="table-row-td">'  +  Reference+ "</td>" +
                                        '<td class="table-row-td">'  +  Amount + "</td>" +
                                        '<td class="table-row-td">'  +  DeliveryMethod + "</td>" +
                                        '<td class="table-row-td">'  +  PaymentMethod + "</td>" +
                                        '<td class="table-row-td">'  +  PaymentStatus + "</td>" +
                                        '<td class="table-row-td">'  +  OrderStatus + "</td>" +
                                    "</tr>"
                    $('#html-table-id tbody').append(tablerow);

                }

            }
            });
}
