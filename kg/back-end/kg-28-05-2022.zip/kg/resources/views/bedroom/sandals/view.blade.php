
<!DOCTYPE html>
<html lang="en" >
<head>
<meta charset="UTF-8">
<title>Bed Room | Sandals | View </title>
<script src="{{asset('js/jquery.min.js')}}"></script>
<script src="{{asset('js/main.js')}}"></script>
<link rel="stylesheet" type="text/css" href="{{asset('css/bootstrap.min.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('css/navabar.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('css/main.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('css/w3.css')}}">

<script>

function Do_Logic ()
{
   OloadInitiApplication ();
}
</script>

</head>

<body onload="Do_Logic ()" class="app-body">
   <nav class="navbar navbar-default no-margin">
      <!-- Brand and toggle get grouped for better mobile display -->
      <div class="side-header-navbar navbar-header fixed-brand">
      <div id="log-name-div" >
         @include ('/MainViews/name')
      </div>
      </div>
      <!-- navbar-header-->
      <div class="header-navbar collapse navbar-collapse" id="bs-example-navbar-collapse-1">
         <ul class="nav navbar-nav">
            <li >
               <button class="menu-btn-link navbar-toggle collapse in" data-toggle="collapse" id="menu-toggle-2">
                  <img src="{{asset('imgs/menu.png')}}" class="menu-fas-img">
               </button>
            </li>
         </ul>

         <div id="header-navbar-inner-div">
            @include ('/MainViews/header')
         </div>
      </div>
      <!-- bs-example-navbar-collapse-1 -->
   </nav>
   <div id="wrapper">
      <!-- Sidebar -->
      <div id="sidebar-wrapper">
         @include ('/MainViews/bedroomNavi')
      </div>
      <!-- /#sidebar-wrapper -->
      <!-- Page Content -->
      <div id="page-content-wrapper">
         <div class="container-fluid main-section-content">
         <label class="page-title-label" >Bed Room | Sandals | List | Products </label>
            
               <div id="quick-links-div-2">
                  @if ($message = Session::get('success'))
                  <div class="alert alert-success" >
                     <p>{{$message}}</p>
                  </div>
                  @endif
                  <div style="text-align:justify; overflow: auto; height: 500px;" class="user-view-area">
                     
                     <table class="w3-card-4">
                     <tr class="table-thead">
                     <th width="10%" class="table-thead-th">Image</th>
                     <th width="8%" class="table-thead-th">Name</th>
                     <th width="5%" class="table-thead-th">Description</th>
                     <th width="5%" class="table-thead-th">Amount</th>
                     <th width="5%" class="table-thead-th">Action1</th>
                     <th width="5%" class="table-thead-th">Action2</th>
                     </tr>

                     @foreach ($data as $row)
                     <tr class="table-row">
                     <td class="table-row-td"><img src="{{URL::to('/')}}/images/{{$row->image}}" class="img-thumbnail" width="75" /></td>
                     <td class="table-row-td">{{$row -> Name}}</td>
                     <td class="table-row-td">{{$row -> Description}}</td>
                     <td class="table-row-td">{{$row -> Amount}}</td>
                     <td class="table-row-td" style="display:none"><a href="{{route('sandalscrud.show',$row->id)}}" class="btn btn-primary" >Details</a>
                     <td class="table-row-td"s><a href="{{route('sandalscrud.edit',$row->id)}}" class="btn btn-warning" >Edit</a></td>
                     <td class="table-row-td">
                        <form action="{{route('sandalscrud.destroy',$row->id)}}" method="post">
                           {{ csrf_field() }}
                              {{method_field('DELETE')}}
                           <button type="submit" class="btn btn-danger" >Delete</button>
                        </form>
                     </td>
                     </tr>
                     @endforeach
                     </table>
                     {!! $data->links() !!}
                  </div>
               </div>
               <!-- <div id="sales-products-outer-div">
                  <div id="sales-chart-div" >
                     <label>Sales Chart</label><br>
                  </div>
                  <div id="top-products-div" >
                     <label>Top Products (February 2022)</label><br>
                  </div>
               </div> -->

            </div>
         </div>
      </div>
      <!-- /#page-content-wrapper -->
   </div>

   <footer class="main-footer">
        <div class="pull-right">
            Version <strong>4.0.19</strong>
        </div>

        <span class="copyright-span"> Copyright © 2022 Liquor Store. All rights reserved.</span>
    </footer>


  <script>
  $("#menu-toggle").click(function(e) {
     e.preventDefault();
     $("#wrapper").toggleClass("toggled");
  });
  $("#menu-toggle-2").click(function(e) {
     e.preventDefault();
     $("#wrapper").toggleClass("toggled-2");
     $('#menu ul').hide();
  });

  function initMenu() {
     $('#menu ul').hide();
     $('#menu ul').children('.current').parent().show();
     //$('#menu ul:first').show();
     $('#menu li a').click(
        function() {
           var checkElement = $(this).next();
           if ((checkElement.is('ul')) && (checkElement.is(':visible'))) {
              return false;
           }
           if ((checkElement.is('ul')) && (!checkElement.is(':visible'))) {
              $('#menu ul:visible').slideUp('normal');
              checkElement.slideDown('normal');
              return false;
           }
        }
     );
  }
  $(document).ready(function() {
     initMenu();
  });
  </script>
</body>
</html>
