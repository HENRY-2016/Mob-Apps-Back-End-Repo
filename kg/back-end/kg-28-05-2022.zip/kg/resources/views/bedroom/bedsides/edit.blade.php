
<!DOCTYPE html>
<html lang="en" >
<head>
<meta charset="UTF-8">
<title>Bed Room | Bed Sides | Edit </title>
<script src="{{asset('js/jquery.min.js')}}"></script>
<script src="{{asset('js/main.js')}}"></script>
<link rel="stylesheet" type="text/css" href="{{asset('css/bootstrap.min.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('css/navabar.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('css/main.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('css/w3.css')}}">

<script>

function Do_Logic ()
{
   OloadInitiApplication ();
}
</script>

</head>

<body onload="Do_Logic ()" class="app-body">
   <nav class="navbar navbar-default no-margin">
      <!-- Brand and toggle get grouped for better mobile display -->
      <div class="side-header-navbar navbar-header fixed-brand">
      <div id="log-name-div" >
         @include ('/MainViews/name')
      </div>
      </div>
      <!-- navbar-header-->
      <div class="header-navbar collapse navbar-collapse" id="bs-example-navbar-collapse-1">
         <ul class="nav navbar-nav">
            <li >
               <button class="menu-btn-link navbar-toggle collapse in" data-toggle="collapse" id="menu-toggle-2">
                  <img src="{{asset('imgs/menu.png')}}" class="menu-fas-img">
               </button>
            </li>
         </ul>

         <div id="header-navbar-inner-div">
            @include ('/MainViews/header')
         </div>
      </div>
      <!-- bs-example-navbar-collapse-1 -->
   </nav>
   <div id="wrapper">
      <!-- Sidebar -->
      <div id="sidebar-wrapper">
         @include ('/MainViews/bedroomNavi')
      </div>
      <!-- /#sidebar-wrapper -->
      <!-- Page Content -->
      <div id="page-content-wrapper">
         <div class="container-fluid main-section-content">
         <label class="page-title-label" >Bed Room | Bed Sides | Edit | Products </label>
            <div id="feedback-popup" class="feedback-popup-window w3-dropdown-content  w3-card-4 w3-animate-zoom">
                  <div id="feedback-div" >
                     <center>
                        <label id="feedback-label" class="feedback-label" ></label>
                     </center><br><br>
                     <button  onclick="OpenFeedbackPopupWindowAndResetForm()" class="btn btn-primary submit-btn">Ok</button>
                  </div>
               </div>
               <div id="quick-links-div-2">
                  @if ($errors -> any())
                  <div class="alert alert-danger" >
                     <ul>
                        @foreach($errors -> all() as $error)
                        <li>{{$error}}</li>
                        @endforeach
                     </ul>
                  </div>
                  @endif
               <form method="post" action="{{route('bedsidescrud.update',$data->id)}}" enctype="multipart/form-data" >
                     {{ csrf_field() }}
                     {{ method_field('PATCH') }}

						<div class="my-grid-container">
                     
							<div class="my-grid-item">
								<label class="input-labels">Name</label><br>
                        <input  required type="text" class="form-control" value="{{$data->Name}}" name="Name" placeholder="Item Name"  autocomplete="off">
							</div>
                     <div class="my-grid-item">
								<label class="input-labels" >Description</label><br>
                        <div class="autocomplete">
                           <input id="ridder-name-input-id" required type="text" class="form-control" value="{{$data->Description}}" name="Description" placeholder="Rider's Name"  autocomplete="off">
                        </div>
							</div>
                     
							<div class="my-grid-item">
								<label class="input-labels" >Amount:</label>
								<input required type="text" required class="form-control" name="Amount" maxlength="10" value="{{$data->Amount}}" oninput="this.value = this.value.replace(/[^0-9.]/g, '')" placeholder="Amount"  autocomplete="off">
							</div>
							
                     
                     <div class="my-grid-item">
								<label class="input-labels" > Image:</label>
                        <input type="file" name="image">
                        <img src="{{URL::to('/')}}/images/{{$data->image}}" class="img-thumbnail" width="100" />
                        <input type="hidden" name="hidden_image" value="{{$data->image}}" />
							</div>

                     <div class="my-grid-item">
                        <button type="submit"  class="btn btn-primary submit-btn">Submit</button>
                     </div>
							
						</div>
					</form>
               </div>
               <!-- <div id="sales-products-outer-div">
                  <div id="sales-chart-div" >
                     <label>Sales Chart</label><br>
                  </div>
                  <div id="top-products-div" >
                     <label>Top Products (February 2022)</label><br>
                  </div>
               </div> -->

            </div>
         </div>
      </div>
      <!-- /#page-content-wrapper -->
   </div>

   <footer class="main-footer">
        <div class="pull-right">
            Version <strong>4.0.19</strong>
        </div>

        <span class="copyright-span"> Copyright © 2022 Liquor Store. All rights reserved.</span>
    </footer>


  <script>
  $("#menu-toggle").click(function(e) {
     e.preventDefault();
     $("#wrapper").toggleClass("toggled");
  });
  $("#menu-toggle-2").click(function(e) {
     e.preventDefault();
     $("#wrapper").toggleClass("toggled-2");
     $('#menu ul').hide();
  });

  function initMenu() {
     $('#menu ul').hide();
     $('#menu ul').children('.current').parent().show();
     //$('#menu ul:first').show();
     $('#menu li a').click(
        function() {
           var checkElement = $(this).next();
           if ((checkElement.is('ul')) && (checkElement.is(':visible'))) {
              return false;
           }
           if ((checkElement.is('ul')) && (!checkElement.is(':visible'))) {
              $('#menu ul:visible').slideUp('normal');
              checkElement.slideDown('normal');
              return false;
           }
        }
     );
  }
  $(document).ready(function() {
     initMenu();
  });
  </script>
</body>
</html>
