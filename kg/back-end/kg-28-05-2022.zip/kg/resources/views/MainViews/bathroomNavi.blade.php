<ul class="sidebar-nav nav-pills nav-stacked" id="menu">



   <li>
      <div id="logo-div">
            <img class="logo-img" src="{{asset('imgs/kg.png')}}" />
         </div>
   </li>
   <br>
   <li >
      <a href="#" class="product-headings"> --- Bath Room Products --- </a>
   </li>
   <br>
   <li class="main-navi-links">
      <a href="/MainViews/dashboard"><img src="{{asset('imgs/dashboard.png')}}" class="my-fas-img">Dashboard</a>
   </li>

   

   <li >
      <a href="#"><img src="{{asset('imgs/bathrobes.png')}}" class="my-fas-img"> Bath Robs &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/bathroom/bathrobs/add"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> Add </a></li>
         <li><a href="{{route('bathrobscrud.index')}}"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>

   <li >
      <a href="#"><img src="{{asset('imgs/towel.png')}}" class="my-fas-img"> Towels &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/bathroom/towels/add"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> Add </a></li>
         <li><a href="{{route('towelscrud.index')}}"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>

   <li >
      <a href="#"><img src="{{asset('imgs/curtains.png')}}" class="my-fas-img"> Curtains &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/bathroom/bathroomcurtains/add"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> Add </a></li>
         <li><a href="{{route('bathroomcurtainscrud.index')}}"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>

   <li >
      <a href="#"><img src="{{asset('imgs/matt.png')}}" class="my-fas-img"> Door Mats &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/bathroom/doormats/add"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> Add </a></li>
         <li><a href="{{route('doormatscrud.index')}}"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>

</ul>