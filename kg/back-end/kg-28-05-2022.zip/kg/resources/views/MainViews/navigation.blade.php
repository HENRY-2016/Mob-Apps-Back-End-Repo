<ul class="sidebar-nav nav-pills nav-stacked" id="menu">
   <li>
      <div id="logo-div">
            <img class="logo-img" src="{{asset('imgs/kg.png')}}" />
         </div>
   </li><br>
   <hr>
   <li class="main-navi-links">
      <a href="/MainViews/dashboard"><img src="{{asset('imgs/dashboard.png')}}" class="my-fas-img">Dashboard</a>
   </li>



   <li >
      <a href="#"><img src="{{asset('imgs/offers.png')}}" class="my-fas-img"> Offers &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/offers/add"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> Add </a></li>
         <li><a href="{{route('offerscrud.index')}}"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>

   <li >
      <a href="#"><img src="{{asset('imgs/babies.png')}}" class="my-fas-img"> Babies &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/babies/add"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> Add </a></li>
         <li><a href="{{route('babiescrud.index')}}"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>

   <li >
      <a href="#"><img src="{{asset('imgs/orders.png')}}" class="my-fas-img"> Orders &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="{{route('orderscrud.index')}}"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> List All</a></li>
         <li><a href="/orders/new"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> List New</a></li>
         <li><a href="/orders/pending"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> List Pending</a></li>
         <li><a href="/orders/cleared"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> List Cleared</a></li>
      </ul>
   </li>

   <li >
      <a href="#"><img src="{{asset('imgs/home.png')}}" class="my-fas-img"> Home &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/home/add"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> Add </a></li>
         <li><a href="{{route('homecrud.index')}}"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>

   <li >
      <a href="#"><img src="{{asset('imgs/about.png')}}" class="my-fas-img"> About &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/about/add"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> Add </a></li>
         <li><a href="{{route('aboutcrud.index')}}"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>

   <li >
      <a href="#"><img src="{{asset('imgs/images.png')}}" class="my-fas-img"> Slider &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/slider/add"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> Add </a></li>
         <li><a href="{{route('slidercrud.index')}}"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>
<!--
   <li >
      <a href="#"><img src="{{asset('imgs/customers.png')}}" class="my-fas-img"> Customers &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
          <li><a href="/customers/add"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> Add </a></li>
         <li><a href="{{route('customerscrud.index')}}"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>-->

   <li >
      <a href="#"><img src="{{asset('imgs/blackfriday.png')}}" class="my-fas-img"> Black Friday &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/blackfriday/add"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> Add </a></li>
         <li><a href="{{route('blackfridaycrud.index')}}"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>

   <li >
      <a href="#"><img src="{{asset('imgs/payments.png')}}" class="my-fas-img"> Payments &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/payments/all"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img">List All </a></li>
         <li><a href="/payments/new"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img">List New </a></li>
         <li><a href="/payments/full"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> List Full</a></li>
         <li><a href="/payments/half"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> List Half</a></li>
         <li><a href="/payments/pending"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img">List Pending </a></li>
      </ul>
   </li>


   <li >
      <hr>
      <a href="#" class="product-headings"> --- All Main Products --- <i class='fa fa-angle-down pointing-arrows'></i></a>
   </li>

   <li >
      <a href="/bedroom/beds/add"><img src="{{asset('imgs/bedroom.png')}}" class="my-fas-img"> Bed Room &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
   </li>

   <li >
      <a href="/livingroom/curtains/add"><img src="{{asset('imgs/livingroom.png')}}" class="my-fas-img"> Living Room &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
   </li>

   <li >
      <a href="/bathroom/bathrobs/add"><img src="{{asset('imgs/curtains.png')}}" class="my-fas-img"> Bath Room &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
   </li>
      <hr>
</ul>
