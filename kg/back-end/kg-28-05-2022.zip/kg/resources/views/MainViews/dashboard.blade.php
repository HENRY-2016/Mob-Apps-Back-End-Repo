
<!DOCTYPE html>
<html lang="en" >
<head>
<meta charset="UTF-8">
<title>Dashboard </title>
<script src="{{asset('js/jquery.min.js')}}"></script>
<script src="{{asset('js/main.js')}}"></script>
<link rel="stylesheet" type="text/css" href="{{asset('css/bootstrap.min.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('css/navabar.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('css/main.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('css/w3.css')}}">

<script>
function InitDashBoard ()
{
   OloadInitiApplication();
   LogInUser()
   Show_Dashboard_Orders_Status(APIListDashboardClearedPayments,'cleared-order-customer-id','cleared-order-amount-id');
   Show_Dashboard_Orders_Status(APIListDashboardNotClearedPayments,'pending-order-customer-id','pending-order-amount-id');
   Show_Dashboard_Orders_Status(APIListDashboardNewOrders,'new-order-customer-id','new-order-amount-id');
   Show_Dashboard_Orders_Status(APIListDashboardTotalOrders,'total-order-customer-id','total-order-amount-id');

   Show_Dashboard_Payments_Status(APIListDashboardNewPayments,'new-payment-customer-id','new-payment-amount-id');
   Show_Dashboard_Orders_Status(APIListDashboardPendingPayments,'pending-payment-customer-id','pending-payment-amount-id');
   Show_Dashboard_Payments_Status(APIListDashboardHalfPayments,'half-payment-customer-id','half-payment-amount-id');
   Show_Dashboard_Payments_Status(APIListDashboardFullPayments,'full-payment-customer-id','full-payment-amount-id');
   Show_Dashboard_Payments_Status(APIListDashboardTotalPayments,'total-payment-customer-id','total-payment-amount-id');

}

</script>

</head>

<body onload=" InitDashBoard()" class="app-body">
   <nav class="navbar navbar-default no-margin">
      <!-- Brand and toggle get grouped for better mobile display -->
      <div class="side-header-navbar navbar-header fixed-brand">
         <div id="log-name-div" >
            @include('/MainViews/name')
         </div>
      </div>
      <!-- navbar-header-->
      <div class="header-navbar collapse navbar-collapse" id="bs-example-navbar-collapse-1">
         <ul class="nav navbar-nav">
            <li >
               <button class="menu-btn-link navbar-toggle collapse in" data-toggle="collapse" id="menu-toggle-2">
                  <img src="{{asset('imgs/menu.png')}}" class="menu-fas-img">
               </button>
            </li>
         </ul>

         <div id="header-navbar-inner-div">
            @include ('/MainViews/header')
         </div>
      </div>
      <!-- bs-example-navbar-collapse-1 -->
   </nav>
   <div id="wrapper">
         
      <!-- Sidebar -->
      <div id="sidebar-wrapper">
         @include ('/MainViews/navigation')
      </div>
      <!-- /#sidebar-wrapper -->
      <!-- Page Content -->
      <div id="page-content-wrapper">
         <div class="container-fluid main-section-content">
            <label class="page-title-label">Dashboard</label>
               <div id="quick-links-div">
                  <div class="dashboard-grid-container">
                     <div class="dashboard-grid-item ">
                        <div class="dashboard-icon-div fuel-card">
                           <img src="{{asset('imgs/dashboard/1.png')}}" class="dashboard-fas-img">
                        </div>
                        <div class="dashboard-label-div-2">
                           <label class="dashboard-labels">
                              New Orders<br>
                                 <center><span id="new-order-customer-id"></span></center>
                                 <center><span id="new-order-amount-id"></span></center>

                           </label>
                        </div>
                     </div>

                     <div class="dashboard-grid-item ">
                        <div class="dashboard-icon-div oil-card">
                           <img src="{{asset('imgs/dashboard/3.png')}}" class="dashboard-fas-img">
                        </div>
                        <div class="dashboard-label-div-2">
                           <label class="dashboard-labels">
                              Pending Orders<br>
                                 <center><span id="pending-order-customer-id"></span></center>
                                 <center><span id="pending-order-amount-id"></span></center>
                           </label>
                        </div>
                     </div>

                     <div class="dashboard-grid-item ">
                        <div class="dashboard-icon-div expenses-card">
                           <img src="{{asset('imgs/dashboard/4.png')}}" class="dashboard-fas-img">
                        </div>
                        <div class="dashboard-label-div-2">
                           <label class="dashboard-labels">
                                 Cleared Orders<br>
                                 <center><span id="cleared-order-customer-id"></span></center>
                                 <center><span id="cleared-order-amount-id"></span></center>
                           </label>
                        </div>
                     </div>

                     <div class="dashboard-grid-item">
                        <div class="dashboard-icon-div ridders-card">
                           <img src="{{asset('imgs/dashboard/2.png')}}" class="dashboard-fas-img">
                        </div>
                        <div class="dashboard-label-div-2">
                           <label class="dashboard-labels">
                              Total Orders<br>
                                 <center><span id="total-order-customer-id"></span></center>
                                 <center><span id="total-order-amount-id"></span></center>
                           </label>
                        </div>
                     </div>

                     <div class="dashboard-grid-item ">
                        <div class="dashboard-icon-div fuel-card">
                           <img src="{{asset('imgs/dashboard/5.png')}}" class="dashboard-fas-img">
                        </div>
                        <div class="dashboard-label-div-2">
                           <label class="dashboard-labels">
                              New Payments<br>
                                 <center><span id="new-payment-customer-id"></span></center>
                                 <center><span id="new-payment-amount-id"></span></center>
                           </label>
                        </div>
                     </div>

                     <div class="dashboard-grid-item">
                        <div class="dashboard-icon-div oil-card">
                           <img src="{{asset('imgs/dashboard/7.png')}}" class="dashboard-fas-img">
                        </div>
                        <div class="dashboard-label-div-2">
                           <label class="dashboard-labels">
                              Pending Payments <br>
                              <center><span id="pending-payment-customer-id"></span></center>
                              <center><span id="pending-payment-amount-id"></span></center>
                           </label>
                        </div>
                     </div>

                     <div class="dashboard-grid-item ">
                        <div class="dashboard-icon-div defaulters-card">
                           <img src="{{asset('imgs/dashboard/8.png')}}" class="dashboard-fas-img">
                        </div>
                        <div class="dashboard-label-div-2">
                           <label class="dashboard-labels">
                              Half Payments<br>
                              <center><span id="half-payment-customer-id"></span></center>
                              <center><span id="half-payment-amount-id"></span></center>
                           </label>
                        </div>
                     </div>

                     <div class="dashboard-grid-item ">
                        <div class="dashboard-icon-div defaulters-card">
                           <img src="{{asset('imgs/dashboard/8.png')}}" class="dashboard-fas-img">
                        </div>
                        <div class="dashboard-label-div-2">
                           <label class="dashboard-labels">
                              Full Payments<br>
                              <center><span id="full-payment-customer-id"></span></center>
                              <center><span id="full-payment-amount-id"></span></center>
                           </label>
                        </div>
                     </div>

                     <div class="dashboard-grid-item ">
                        <div class="dashboard-icon-div ridders-card">
                              <img src="{{asset('imgs/dashboard/6.png')}}" class="dashboard-fas-img">
                           </div>
                           <div class="dashboard-label-div-2">
                              <label class="dashboard-labels">
                                 Total Payments<br>
                                 <center><span id="total-payment-customer-id"></span></center>
                                 <center><span id="total-payment-amount-id"></span></center>
                              </label>
                           </div>
                     </div>

                     <!-- <div class="dashboard-grid-item">
                        <div class="dashboard-icon-div fuel-card">
                           <img src="{{asset('imgs/fuel.png')}}" class="dashboard-fas-img">
                        </div>
                        <div class="dashboard-label-div-2">
                           <label class="dashboard-labels">
                              Fuel Payments<br>
                                 <center><span id="fuel-payments-span"></span></center>
                           </label>
                        </div>
                     </div>

                     <div class="dashboard-grid-item ">
                           <div class="dashboard-icon-div oil-card">
                              <img src="{{asset('imgs/oil.png')}}" class="dashboard-fas-img">
                           </div>
                        <div class="dashboard-label-div-2">
                           <label class="dashboard-labels">
                           Oil Payments<br>
                                 <center><span id="oil-payments-span"></span></center>
                           </label>
                        </div>
                     </div>

                     <div class="dashboard-grid-item">
                        <div class="dashboard-icon-div defaulters-card">
                           <img src="{{asset('imgs/oil.png')}}" class="dashboard-fas-img">
                        </div>
                        <div class="dashboard-label-div-2">
                           <label class="dashboard-labels">
                              Oil Defaulters<br>
                                 <center><span id="oil-defaulters-span"></span></center>
                           </label>
                        </div>
                     </div>

                     <div class="dashboard-grid-item ">
                        <div class="dashboard-icon-div staff-card">
                                 <img src="{{asset('imgs/staff.png')}}" class="dashboard-fas-img">
                           </div>
                           <div class="dashboard-label-div-2">
                              <label class="dashboard-labels">
                                    Total Staffs<br>
                                       <center><span id="staff-span"></span></center>
                                 </label>
                           </div>
                     </div> -->


                  </div>
               </div>
               <!-- <div id="sales-products-outer-div">
                  <div id="sales-chart-div" >
                     <label>Dr.Kg</label><br>
               </div>
               <div id="top-products-div" style="display:none" >
                     <label class="page-title-label">Todys</label>
                     <center>
                     <br>
                     <label class="page-title-label">Total Oil Collections:<span id="oil-collection-id">  </span> </label><br>
                     <label class="page-title-label">Total Fuel Collections:<span id="fuel-collection-id">  </span> </label><br>
                     <label class="page-title-label">Total Expenses Made:<span id="expenses-collection-id">  </span> </label><br>
                     <label class="page-title-label">-----------------------------------------------</label><br>
                     <label class="page-title-label">Total Oil & Fuel:<span id="oil-fuel-id">  </span> </label><br>
                     <label class="page-title-label">Total Expenses :<span id="expenses-id">  </span> </label><br>
                     <label class="page-title-label">Balance:<span id="balance-id">  </span> </label><br>
                  </center>
               </div>
               </div> -->

            </div>
         </div>
      </div>
      <!-- /#page-content-wrapper -->
   </div>

   <footer class="main-footer">
        <div class="pull-right">
            Version <strong>4.0.19</strong>
        </div>

        <span class="copyright-span"> Copyright © 2022 Liquor Store. All rights reserved.</span>
    </footer>


  <script>
  $("#menu-toggle").click(function(e) {
     e.preventDefault();
     $("#wrapper").toggleClass("toggled");
  });
  $("#menu-toggle-2").click(function(e) {
     e.preventDefault();
     $("#wrapper").toggleClass("toggled-2");
     $('#menu ul').hide();
  });

  function initMenu() {
     $('#menu ul').hide();
     $('#menu ul').children('.current').parent().show();
     //$('#menu ul:first').show();
     $('#menu li a').click(
        function() {
           var checkElement = $(this).next();
           if ((checkElement.is('ul')) && (checkElement.is(':visible'))) {
              return false;
           }
           if ((checkElement.is('ul')) && (!checkElement.is(':visible'))) {
              $('#menu ul:visible').slideUp('normal');
              checkElement.slideDown('normal');
              return false;
           }
        }
     );
  }
  $(document).ready(function() {
     initMenu();
  });
  </script>
</body>
</html>
