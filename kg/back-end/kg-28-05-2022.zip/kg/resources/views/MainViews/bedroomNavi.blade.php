<ul class="sidebar-nav nav-pills nav-stacked" id="menu">
   <li>
      <div id="logo-div">
            <img class="logo-img" src="{{asset('imgs/kg.png')}}" />
         </div>
   </li>
   <br>
   <li >
      <a href="#" class="product-headings"> --- Bed Room Products --- </a>
   </li>
   <br>
   <li class="main-navi-links">
      <a href="/MainViews/dashboard"><img src="{{asset('imgs/dashboard.png')}}" class="my-fas-img">Dashboard</a>
   </li>

   <li >
      <a href="#"><img src="{{asset('imgs/bedroom.png')}}" class="my-fas-img"> Beds &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/bedroom/beds/add"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> Add </a></li>
         <li><a href="{{route('bedscrud.index')}}"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>

   <li >
      <a href="#"><img src="{{asset('imgs/nets.png')}}" class="my-fas-img"> Nets &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/bedroom/nets/add"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> Add </a></li>
         <li><a href="{{route('netscrud.index')}}"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>

   <li >
      <a href="#"><img src="{{asset('imgs/cover.png')}}" class="my-fas-img"> Bed Covers &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/bedroom/bedcovers/add"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> Add </a></li>
         <li><a href="{{route('bedscoverscrud.index')}}"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>

   <li >
      <a href="#"><img src="{{asset('imgs/pillows.png')}}" class="my-fas-img"> Pillows &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/bedroom/pillows/add"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> Add </a></li>
         <li><a href="{{route('pillowscrud.index')}}"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>

   <li >
      <a href="#"><img src="{{asset('imgs/closet.png')}}" class="my-fas-img"> Closet &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/bedroom/closet/add"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> Add </a></li>
         <li><a href="{{route('closetcrud.index')}}"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>

   <li >
      <a href="#"><img src="{{asset('imgs/cussions.png')}}" class="my-fas-img"> Cussions &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/bedroom/cussions/add"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> Add </a></li>
         <li><a href="{{route('cussionscrud.index')}}"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>

   <li >
      <a href="#"><img src="{{asset('imgs/shoe.png')}}" class="my-fas-img"> Shoe Rack &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="bedroom/shoerack/add"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> Add </a></li>
         <li><a href="{{route('shoerackcrud.index')}}"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>

   <li >
      <a href="#"><img src="{{asset('imgs/sheets.png')}}" class="my-fas-img"> Bed Sheets &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/bedroom/bedsheets/add"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> Add </a></li>
         <li><a href="{{route('bedsheetscrud.index')}}"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>

   <li >
      <a href="#"><img src="{{asset('imgs/blanket.png')}}" class="my-fas-img"> Blankets &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/bedroom/blankets/add"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> Add </a></li>
         <li><a href="{{route('blanketscrud.index')}}"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>

   <li >
      <a href="#"><img src="{{asset('imgs/mattress.png')}}" class="my-fas-img"> Mattress &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/bedroom/mattress/add"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> Add </a></li>
         <li><a href="{{route('mattresscrud.index')}}"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>
   <li >
      <a href="#"><img src="{{asset('imgs/matprotector.png')}}" class="my-fas-img">Mattress Protectors <i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/bedroom/mattressprotectors/add"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> Add </a></li>
         <li><a href="{{route('mattressprotectorscrud.index')}}"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>

   <li >
      <a href="#"><img src="{{asset('imgs/sandals.png')}}" class="my-fas-img"> Sandals &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/bedroom/sandals/add"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> Add </a></li>
         <li><a href="{{route('sandalscrud.index')}}"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>

   <li >
      <a href="#"><img src="{{asset('imgs/side.png')}}" class="my-fas-img"> Bed Sides &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/bedroom/bedsides/add"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> Add </a></li>
         <li><a href="{{route('bedsidescrud.index')}}"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>

   <li >
      <a href="#"><img src="{{asset('imgs/mirror.png')}}" class="my-fas-img">Dressing Mirriors <i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/bedroom/mirrors/add"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> Add </a></li>
         <li><a href="{{route('mirrorscrud.index')}}"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>

   <li >
      <a href="#"><img src="{{asset('imgs/night.png')}}" class="my-fas-img">Night Ware &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/bedroom/nightware/add"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> Add </a></li>
         <li><a href="{{route('nightwarecrud.index')}}"><img src="{{asset('imgs/circle.png')}}" class="my-list-fas-img"> List</a></li>
      </ul>
   </li> 



</ul>