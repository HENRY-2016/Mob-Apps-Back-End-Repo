<button class="header-semi-navi-btn"><span class="date-span-class" id="date-span" ></span></button>
<label class="date-span-class">Admin</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<button type="button" onclick="Log_Out_User ()" class="btn btn-danger">Log Out</button>
&nbsp;&nbsp;&nbsp;