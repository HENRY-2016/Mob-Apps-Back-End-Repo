
<!DOCTYPE html>
<html lang="en" >
<head>
<meta charset="UTF-8">
<title>Orders | List </title>
<script src="{{asset('js/jquery.min.js')}}"></script>
<script src="{{asset('js/main.js')}}"></script>
<link rel="stylesheet" type="text/css" href="{{asset('css/bootstrap.min.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('css/navabar.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('css/main.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('css/w3.css')}}">

<script>

function Do_Logic ()
{
   OloadInitiApplication ();
}
</script>

</head>

<body onload="Do_Logic ()" class="app-body">
   <nav class="navbar navbar-default no-margin">
      <!-- Brand and toggle get grouped for better mobile display -->
      <div class="side-header-navbar navbar-header fixed-brand">
      <div id="log-name-div" >
         @include ('/MainViews/name')
      </div>
      </div>
      <!-- navbar-header-->
      <div class="header-navbar collapse navbar-collapse" id="bs-example-navbar-collapse-1">
         <ul class="nav navbar-nav">
            <li >
               <button class="menu-btn-link navbar-toggle collapse in" data-toggle="collapse" id="menu-toggle-2">
                  <img src="{{asset('imgs/menu.png')}}" class="menu-fas-img">
               </button>
            </li>
         </ul>

         <div id="header-navbar-inner-div">
            @include ('/MainViews/header')
         </div>
      </div>
      <!-- bs-example-navbar-collapse-1 -->
   </nav>
   <div id="wrapper">
      <!-- Sidebar -->
      <div id="sidebar-wrapper">
         @include ('/MainViews/navigation')
      </div>
      <!-- /#sidebar-wrapper -->
      <!-- Page Content -->
      <div id="page-content-wrapper">
         <div class="container-fluid main-section-content">
         <label class="page-title-label" >Orders | List | Orders</label>
            
               <div id="orders-view-div">
                  @if ($message = Session::get('success'))
                  <div class="alert alert-success" >
                     <p>{{$message}}</p>
                  </div>
                  @endif
                  <div id="orderlist-table-view-div">
                     <div style="text-align:justify; overflow: auto; height: 500px;" class="user-view-area">
                        <table class="w3-card-4">
                        <tr class="table-thead">
                        <th width="10%" class="table-thead-th">Phone</th>
                        <th width="10%" class="table-thead-th">Date</th>
                        <th width="10%" class="table-thead-th">Delivery</th>
                        <th width="5%" class="table-thead-th">Method</th>
                        <th width="5%" class="table-thead-th">Reference</th>
                        <th width="5%" class="table-thead-th">Amount</th>
                        <th width="5%" class="table-thead-th">Payments</th>
                        <th width="5%" class="table-thead-th">Status</th>
                        <th width="5%" class="table-thead-th">Action1</th>
                        <th width="5%" class="table-thead-th">Action2</th>
                        <th width="5%"  style="display:none" class="table-thead-th">Action3</th>
                        </tr>

                        @foreach ($data as $row)
                        <tr class="table-row">
                        <td class="table-row-td">{{$row -> Phone}}</td>
                        <td class="table-row-td">{{$row -> PalaceHolderOne}}</td>
                        <td class="table-row-td">{{$row -> DeliveryMethod}}</td>
                        <td class="table-row-td">{{$row ->  PaymentMethod}}</td>
                        <td class="table-row-td">{{$row ->  Reference}}</td>
                        <td class="table-row-td">{{$row -> Amount}}</td>
                        <td class="table-row-td">{{$row -> PalaceHolderTwo}}</td>
                        <td class="table-row-td">{{$row -> Status}}</td>
                           
                        <td class="table-row-td"><button onclick="Show_Customer_Order_Details ({{$row -> id}})" class="btn btn-primary" >Details</button>
                        <td class="table-row-td"><a href="{{route('orderscrud.edit',$row->id)}}" class="btn btn-warning" >Change Status</a></td>
                        <td class="table-row-td" style="display:none">
                        <form  action="{{route('orderscrud.destroy',$row->id)}}" method="post">
                           {{ csrf_field() }}
                              {{method_field('DELETE')}}
                           <button type="submit"  class="btn btn-danger" >Delete</button>
                        </form>
                     </td>
                        </tr>
                        @endforeach
                        </table>
                        {!! $data->links() !!}
                     </div>
                  </div>
                  <div id="orderlist-details-view-div">
                     <!-- <br>
                     <div id="navi-links">
                        <a href="/station/front-end/oil/view.php"><button type="button" class="btn btn-info">List</button></a>
                     </div> -->
                     
                     <!-- <label id="id"></label> -->
                     <br><br>
                     <label class="details-labels">Phone :: <span id="phone"></span></label><br>
                     <label class="details-labels">Status :: <span id="status"></span></label><br>
                     <label class="details-labels">Order Number :: <span id="ordernumber"></span></label><br>
                     <label class="details-labels">DeliveryMethod :: <span id="DeliveryMethod"></span></label><br>
                     <label class="details-labels">PaymentMethod :: <span id="PaymentMethod"></span></label><br>
                     <label class="details-labels">Total Amount :: <span id="amount"></span></label><br>
                     <label class="details-labels">Order Time :: <span id="time"></span></label><br><br>
                     <div id="order-list-space-div"></div>
                     <div id="mycard"></div>


                  </div>
               </div>
               <!-- <div id="sales-products-outer-div">
                  <div id="sales-chart-div" >
                     <label>Sales Chart</label><br>
                  </div>
                  <div id="top-products-div" >
                     <label>Top Products (February 2022)</label><br>
                  </div>
               </div> -->

            </div>
         </div>
      </div>
      <!-- /#page-content-wrapper -->
   </div>

   <footer class="main-footer">
        <div class="pull-right">
            Version <strong>4.0.19</strong>
        </div>

        <span class="copyright-span"> Copyright © 2022 Liquor Store. All rights reserved.</span>
    </footer>


  <script>
  $("#menu-toggle").click(function(e) {
     e.preventDefault();
     $("#wrapper").toggleClass("toggled");
  });
  $("#menu-toggle-2").click(function(e) {
     e.preventDefault();
     $("#wrapper").toggleClass("toggled-2");
     $('#menu ul').hide();
  });

  function initMenu() {
     $('#menu ul').hide();
     $('#menu ul').children('.current').parent().show();
     //$('#menu ul:first').show();
     $('#menu li a').click(
        function() {
           var checkElement = $(this).next();
           if ((checkElement.is('ul')) && (checkElement.is(':visible'))) {
              return false;
           }
           if ((checkElement.is('ul')) && (!checkElement.is(':visible'))) {
              $('#menu ul:visible').slideUp('normal');
              checkElement.slideDown('normal');
              return false;
           }
        }
     );
  }
  $(document).ready(function() {
     initMenu();
  });
  </script>
</body>
</html>
