<ul class="sidebar-nav nav-pills nav-stacked" id="menu">
   <li>
      <div id="logo-div">
            <img class="logo-img" src="<?php echo e(asset('imgs/kg.png')); ?>" />
         </div>
   </li><br>
   <hr>
   <li class="main-navi-links">
      <a href="/MainViews/dashboard"><img src="<?php echo e(asset('imgs/dashboard.png')); ?>" class="my-fas-img">Dashboard</a>
   </li>



   <li >
      <a href="#"><img src="<?php echo e(asset('imgs/offers.png')); ?>" class="my-fas-img"> Offers &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/offers/add"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> Add </a></li>
         <li><a href="<?php echo e(route('offerscrud.index')); ?>"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>

   <li >
      <a href="#"><img src="<?php echo e(asset('imgs/babies.png')); ?>" class="my-fas-img"> Babies &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/babies/add"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> Add </a></li>
         <li><a href="<?php echo e(route('babiescrud.index')); ?>"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>

   <li >
      <a href="#"><img src="<?php echo e(asset('imgs/orders.png')); ?>" class="my-fas-img"> Orders &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="<?php echo e(route('orderscrud.index')); ?>"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> List All</a></li>
         <li><a href="/orders/new"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> List New</a></li>
         <li><a href="/orders/pending"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> List Pending</a></li>
         <li><a href="/orders/cleared"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> List Cleared</a></li>
      </ul>
   </li>

   <li >
      <a href="#"><img src="<?php echo e(asset('imgs/home.png')); ?>" class="my-fas-img"> Home &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/home/add"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> Add </a></li>
         <li><a href="<?php echo e(route('homecrud.index')); ?>"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>

   <li >
      <a href="#"><img src="<?php echo e(asset('imgs/about.png')); ?>" class="my-fas-img"> About &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/about/add"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> Add </a></li>
         <li><a href="<?php echo e(route('aboutcrud.index')); ?>"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>

   <li >
      <a href="#"><img src="<?php echo e(asset('imgs/images.png')); ?>" class="my-fas-img"> Slider &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/slider/add"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> Add </a></li>
         <li><a href="<?php echo e(route('slidercrud.index')); ?>"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>
<!--
   <li >
      <a href="#"><img src="<?php echo e(asset('imgs/customers.png')); ?>" class="my-fas-img"> Customers &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
          <li><a href="/customers/add"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> Add </a></li>
         <li><a href="<?php echo e(route('customerscrud.index')); ?>"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>-->

   <li >
      <a href="#"><img src="<?php echo e(asset('imgs/blackfriday.png')); ?>" class="my-fas-img"> Black Friday &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/blackfriday/add"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> Add </a></li>
         <li><a href="<?php echo e(route('blackfridaycrud.index')); ?>"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>

   <li >
      <a href="#"><img src="<?php echo e(asset('imgs/payments.png')); ?>" class="my-fas-img"> Payments &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/payments/all"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img">List All </a></li>
         <li><a href="/payments/new"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img">List New </a></li>
         <li><a href="/payments/full"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> List Full</a></li>
         <li><a href="/payments/half"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> List Half</a></li>
         <li><a href="/payments/pending"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img">List Pending </a></li>
      </ul>
   </li>


   <li >
      <hr>
      <a href="#" class="product-headings"> --- All Main Products --- <i class='fa fa-angle-down pointing-arrows'></i></a>
   </li>

   <li >
      <a href="/bedroom/beds/add"><img src="<?php echo e(asset('imgs/bedroom.png')); ?>" class="my-fas-img"> Bed Room &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
   </li>

   <li >
      <a href="/livingroom/curtains/add"><img src="<?php echo e(asset('imgs/livingroom.png')); ?>" class="my-fas-img"> Living Room &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
   </li>

   <li >
      <a href="/bathroom/bathrobs/add"><img src="<?php echo e(asset('imgs/curtains.png')); ?>" class="my-fas-img"> Bath Room &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
   </li>
      <hr>
</ul>
<?php /**PATH /media/lets-code/projects/apps/kg/back-end/kg/resources/views//MainViews/navigation.blade.php ENDPATH**/ ?>