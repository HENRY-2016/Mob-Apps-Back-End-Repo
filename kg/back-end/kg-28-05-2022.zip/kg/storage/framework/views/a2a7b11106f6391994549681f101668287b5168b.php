<ul class="sidebar-nav nav-pills nav-stacked" id="menu">
   <li>
      <div id="logo-div">
            <img class="logo-img" src="<?php echo e(asset('imgs/kg.png')); ?>" />
         </div>
   </li>
   <br>
   <li >
      <a href="#" class="product-headings"> --- Bed Room Products --- </a>
   </li>
   <br>
   <li class="main-navi-links">
      <a href="/MainViews/dashboard"><img src="<?php echo e(asset('imgs/dashboard.png')); ?>" class="my-fas-img">Dashboard</a>
   </li>

   <li >
      <a href="#"><img src="<?php echo e(asset('imgs/bedroom.png')); ?>" class="my-fas-img"> Beds &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/bedroom/beds/add"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> Add </a></li>
         <li><a href="<?php echo e(route('bedscrud.index')); ?>"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>

   <li >
      <a href="#"><img src="<?php echo e(asset('imgs/nets.png')); ?>" class="my-fas-img"> Nets &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/bedroom/nets/add"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> Add </a></li>
         <li><a href="<?php echo e(route('netscrud.index')); ?>"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>

   <li >
      <a href="#"><img src="<?php echo e(asset('imgs/cover.png')); ?>" class="my-fas-img"> Bed Covers &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/bedroom/bedcovers/add"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> Add </a></li>
         <li><a href="<?php echo e(route('bedscoverscrud.index')); ?>"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>

   <li >
      <a href="#"><img src="<?php echo e(asset('imgs/pillows.png')); ?>" class="my-fas-img"> Pillows &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/bedroom/pillows/add"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> Add </a></li>
         <li><a href="<?php echo e(route('pillowscrud.index')); ?>"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>

   <li >
      <a href="#"><img src="<?php echo e(asset('imgs/closet.png')); ?>" class="my-fas-img"> Closet &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/bedroom/closet/add"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> Add </a></li>
         <li><a href="<?php echo e(route('closetcrud.index')); ?>"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>

   <li >
      <a href="#"><img src="<?php echo e(asset('imgs/cussions.png')); ?>" class="my-fas-img"> Cussions &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/bedroom/cussions/add"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> Add </a></li>
         <li><a href="<?php echo e(route('cussionscrud.index')); ?>"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>

   <li >
      <a href="#"><img src="<?php echo e(asset('imgs/shoe.png')); ?>" class="my-fas-img"> Shoe Rack &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="bedroom/shoerack/add"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> Add </a></li>
         <li><a href="<?php echo e(route('shoerackcrud.index')); ?>"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>

   <li >
      <a href="#"><img src="<?php echo e(asset('imgs/sheets.png')); ?>" class="my-fas-img"> Bed Sheets &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/bedroom/bedsheets/add"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> Add </a></li>
         <li><a href="<?php echo e(route('bedsheetscrud.index')); ?>"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>

   <li >
      <a href="#"><img src="<?php echo e(asset('imgs/blanket.png')); ?>" class="my-fas-img"> Blankets &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/bedroom/blankets/add"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> Add </a></li>
         <li><a href="<?php echo e(route('blanketscrud.index')); ?>"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>

   <li >
      <a href="#"><img src="<?php echo e(asset('imgs/mattress.png')); ?>" class="my-fas-img"> Mattress &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/bedroom/mattress/add"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> Add </a></li>
         <li><a href="<?php echo e(route('mattresscrud.index')); ?>"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>
   <li >
      <a href="#"><img src="<?php echo e(asset('imgs/matprotector.png')); ?>" class="my-fas-img">Mattress Protectors <i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/bedroom/mattressprotectors/add"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> Add </a></li>
         <li><a href="<?php echo e(route('mattressprotectorscrud.index')); ?>"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>

   <li >
      <a href="#"><img src="<?php echo e(asset('imgs/sandals.png')); ?>" class="my-fas-img"> Sandals &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/bedroom/sandals/add"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> Add </a></li>
         <li><a href="<?php echo e(route('sandalscrud.index')); ?>"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>

   <li >
      <a href="#"><img src="<?php echo e(asset('imgs/side.png')); ?>" class="my-fas-img"> Bed Sides &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/bedroom/bedsides/add"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> Add </a></li>
         <li><a href="<?php echo e(route('bedsidescrud.index')); ?>"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>

   <li >
      <a href="#"><img src="<?php echo e(asset('imgs/mirror.png')); ?>" class="my-fas-img">Dressing Mirriors <i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/bedroom/mirrors/add"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> Add </a></li>
         <li><a href="<?php echo e(route('mirrorscrud.index')); ?>"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>

   <li >
      <a href="#"><img src="<?php echo e(asset('imgs/night.png')); ?>" class="my-fas-img">Night Ware &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/bedroom/nightware/add"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> Add </a></li>
         <li><a href="<?php echo e(route('nightwarecrud.index')); ?>"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> List</a></li>
      </ul>
   </li> 



</ul><?php /**PATH /media/lets-code/projects/apps/kg/back-end/kg/resources/views//MainViews/bedroomNavi.blade.php ENDPATH**/ ?>