

<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Login</title>

<script src="<?php echo e(asset('js/main.js')); ?>"></script>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/main.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/w3.css')); ?>">
</head>
<body class="log-in-body">
    <div id="card">
    <div id="card-content">
    <div id="login-logo-div">
        <center>
            <img style="margin-left:40px" class="logo-img" src="<?php echo e(asset('imgs/kg.png')); ?>" />
          </center>
        </div>
      <div id="card-title">
      
        <label class="login-title-label" > Please Login First.</label>

      </div>
          <form  style="max-width:500px;margin:auto" method="post">

          <!-- <div class="input-container">
              <i class="fa fa-key icon"></i>
                <select required class="input-field" autocomplete="off" name="usertype" >
                  <option>Select User Type</option>
                  <option value="Admin">Admin</option>
                  <option value="Staff">Staff</option>
                </select>
            </div> -->

            <div class="input-container">
              <i class="fa fa-user icon"></i>
              <input id="username" class="input-field" type="text"  name="username" autocomplete="off" required="required" placeholder="Username">
            </div>

            

            <div class="input-container">
              <i class="fa fa-key icon"></i>
              <input id="password" class="input-field" type="password" autocomplete="off" required="required" placeholder="Password" name="password">
            </div>
            <button type="button" onclick="LogInUser ()"  name="user-login-btn" class="log-in-btn">Log In</button>

      </form>
    </div>
  </div>

<script>

function LogInUser ()
{
  let username = document.getElementById("username").value;
  let password = document.getElementById("password").value;

  if (username == "Admin" && password == "Admin@2022")
      {
          localStorage.setItem("username",username);
          window.location= baseUrl+"/dashboard"
      }
      else {alert("Invalid Password or Username");}
}

</script>
</body>
</html>
<?php /**PATH /media/lets-code/projects/apps/kg/back-end/kg/resources/views/MainViews/index.blade.php ENDPATH**/ ?>