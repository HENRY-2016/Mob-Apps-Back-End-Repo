<ul class="sidebar-nav nav-pills nav-stacked" id="menu">



   <li>
      <div id="logo-div">
            <img class="logo-img" src="<?php echo e(asset('imgs/kg.png')); ?>" />
         </div>
   </li>
   <br>
   <li >
      <a href="#" class="product-headings"> --- Bath Room Products --- </a>
   </li>
   <br>
   <li class="main-navi-links">
      <a href="/MainViews/dashboard"><img src="<?php echo e(asset('imgs/dashboard.png')); ?>" class="my-fas-img">Dashboard</a>
   </li>

   

   <li >
      <a href="#"><img src="<?php echo e(asset('imgs/bathrobes.png')); ?>" class="my-fas-img"> Bath Robs &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/bathroom/bathrobs/add"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> Add </a></li>
         <li><a href="<?php echo e(route('bathrobscrud.index')); ?>"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>

   <li >
      <a href="#"><img src="<?php echo e(asset('imgs/towel.png')); ?>" class="my-fas-img"> Towels &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/bathroom/towels/add"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> Add </a></li>
         <li><a href="<?php echo e(route('towelscrud.index')); ?>"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>

   <li >
      <a href="#"><img src="<?php echo e(asset('imgs/curtains.png')); ?>" class="my-fas-img"> Curtains &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/bathroom/bathroomcurtains/add"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> Add </a></li>
         <li><a href="<?php echo e(route('bathroomcurtainscrud.index')); ?>"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>

   <li >
      <a href="#"><img src="<?php echo e(asset('imgs/matt.png')); ?>" class="my-fas-img"> Door Mats &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/bathroom/doormats/add"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> Add </a></li>
         <li><a href="<?php echo e(route('doormatscrud.index')); ?>"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>

</ul><?php /**PATH /media/lets-code/projects/apps/kg/back-end/kg/resources/views//MainViews/bathroomNavi.blade.php ENDPATH**/ ?>