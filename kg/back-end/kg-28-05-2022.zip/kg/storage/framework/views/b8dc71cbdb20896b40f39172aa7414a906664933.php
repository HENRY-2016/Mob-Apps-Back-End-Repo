<ul class="sidebar-nav nav-pills nav-stacked" id="menu">
   <li>
      <div id="logo-div">
            <img class="logo-img" src="<?php echo e(asset('imgs/kg.png')); ?>" />
         </div>
   </li>
 
   <br>
   <li >
      <a href="#" class="product-headings"> --- Living Room Products ---</a>
   </li>
   <br>
   <li class="main-navi-links">
      <a href="/MainViews/dashboard"><img src="<?php echo e(asset('imgs/dashboard.png')); ?>" class="my-fas-img">Dashboard</a>
   </li>

   <li >
      <a href="#"><img src="<?php echo e(asset('imgs/curtains-2.png')); ?>" class="my-fas-img"> Curtains &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/livingroom/curtains/add"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> Add </a></li>
         <li><a href="<?php echo e(route('curtainscrud.index')); ?>"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>

   <li >
      <a href="#"><img src="<?php echo e(asset('imgs/seats.png')); ?>" class="my-fas-img"> Seats &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/livingroom/seats/add"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> Add </a></li>
         <li><a href="<?php echo e(route('seatscrud.index')); ?>"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>

   <li >
      <a href="#"><img src="<?php echo e(asset('imgs/sideboard.png')); ?>" class="my-fas-img"> Side boards &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/livingroom/sideboards/add"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> Add </a></li>
         <li><a href="<?php echo e(route('sideboardscrud.index')); ?>"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>

   <li >
      <a href="#"><img src="<?php echo e(asset('imgs/table.png')); ?>" class="my-fas-img"> Tables &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/livingroom/tables/add"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> Add </a></li>
         <li><a href="<?php echo e(route('tablescrud.index')); ?>"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>

   <li >
      <a href="#"><img src="<?php echo e(asset('imgs/carpet.png')); ?>" class="my-fas-img"> Carpets &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/livingroom/carpets/add"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> Add </a></li>
         <li><a href="<?php echo e(route('carpetscrud.index')); ?>"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>

   <li >
      <a href="#"><img src="<?php echo e(asset('imgs/ironing.png')); ?>" class="my-fas-img"> Ironing Board <i class='fa fa-angle-down pointing-arrows'></i></a>
      <ul class="nav-pills nav-stacked nav-drop-down-list-links">
         <li><a href="/livingroom/ironingboard/add"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> Add </a></li>
         <li><a href="<?php echo e(route('ironingboardcrud.index')); ?>"><img src="<?php echo e(asset('imgs/circle.png')); ?>" class="my-list-fas-img"> List</a></li>
      </ul>
   </li>



</ul><?php /**PATH /media/lets-code/projects/apps/kg/back-end/kg/resources/views//MainViews/livingroomNavi.blade.php ENDPATH**/ ?>