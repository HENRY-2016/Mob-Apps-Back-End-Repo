<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('offers_table', function (Blueprint $table) {
            //
            $table->string('PalaceHolderOne')->default('');
            $table->string('PalaceHolderTwo')->default('');
            $table->string('PalaceHolderThree')->default('');
            $table->string('PalaceHolderFour')->default('');
            $table->string('PalaceHolderFive')->default('');
            $table->string('PalaceHolderSix')->default('');
            $table->string('PalaceHolderSeven')->default('');
            $table->string('PalaceHolderEight')->default('');
            $table->string('PalaceHolderNine')->default('');
            $table->string('PalaceHolderTen')->default('');
            $table->string('PalaceHolder11')->default('');
            $table->string('PalaceHolder12')->default('');
            $table->string('PalaceHolder13')->default('');
            $table->string('PalaceHolder14')->default('');
            $table->string('PalaceHolder15')->default('');

            
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('offers_table', function (Blueprint $table) {
            //
            $table->dropColumn(['PalaceHolderOne','PalaceHolderTwo','PalaceHolderThree','PalaceHolderFour','PalaceHolderFive','PalaceHolderSix','PalaceHolderSeven','PalaceHolderEight','PalaceHolderNine','PalaceHolderTen','PalaceHolder11','PalaceHolder12','PalaceHolder13','PalaceHolder14','PalaceHolder15']);
        });
    }
};
