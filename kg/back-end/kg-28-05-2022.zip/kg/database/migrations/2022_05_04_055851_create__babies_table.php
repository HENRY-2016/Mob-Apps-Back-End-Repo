<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('Babies_table', function (Blueprint $table) {
            $table->id();
            $table->string('Name');
            $table->string('Description');
            $table->string('Amount');
            $table->string('image');
            $table->string('PalaceHolderOne');
            $table->string('PalaceHolderTwo');
            $table->string('PalaceHolderThree');
            $table->string('PalaceHolderFour');
            $table->string('PalaceHolderFive');
            $table->string('PalaceHolderSix');
            $table->string('PalaceHolderSeven');
            $table->string('PalaceHolderEight');
            $table->string('PalaceHolderNine');
            $table->string('PalaceHolderTen');
            $table->string('PalaceHolder11');
            $table->string('PalaceHolder12');
            $table->string('PalaceHolder13');
            $table->string('PalaceHolder14');
            $table->string('PalaceHolder15');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('Babies_table');
    }
};
