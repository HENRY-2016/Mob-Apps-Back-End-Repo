<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('About_table', function (Blueprint $table) {
            //
            $table->string('Bank1Names')->default('');
            $table->string('Bank2Names')->default('');
            $table->string('Bank1')->default('');
            $table->string('Bank2')->default('');
            $table->string('Tell2Names')->default('');
            $table->string('Tell1Names')->default('');
            $table->string('Tell1')->default('');
            $table->string('Tell2')->default('');
            $table->string('PalaceHolderOne')->default('');
            $table->string('PalaceHolderTwo')->default('');
            $table->string('PalaceHolderThree')->default('');
            $table->string('PalaceHolderFour')->default('');
            $table->string('PalaceHolderFive')->default('');
            $table->string('PalaceHolderSix')->default('');
            $table->string('PalaceHolderSeven')->default('');
            $table->string('PalaceHolderEight')->default('');
            $table->string('PalaceHolderNine')->default('');
            $table->string('PalaceHolderTen')->default('');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('About_table', function (Blueprint $table) {
            //
            $table->dropColumn(['Bank1Names','Bank2Names','Bank1','Bank2','Tell1Names','Tell2Names','Tell1','Tell2','PalaceHolderOne','PalaceHolderTwo','PalaceHolderThree','PalaceHolderFour','PalaceHolderFive','PalaceHolderSix','PalaceHolderSeven','PalaceHolderEight','PalaceHolderNine','PalaceHolderTen']);
        });
    }
};
