<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('orders_table', function (Blueprint $table) {
            $table->id();
            $table->string('Name');
            $table->string('Phone');
            $table->string('Address');
            $table->string('Reference');
            $table->string('Amount');
            $table->string('Status');
            $table->string('DeliveryMethod');
            $table->string('PaymentMethod');
            $table->string('PalaceHolderOne');
            $table->string('PalaceHolderTwo');
            $table->string('PalaceHolderThree');
            $table->string('PalaceHolderFour');
            $table->string('PalaceHolderFive');
            $table->string('PalaceHolderSix');
            $table->string('PalaceHolderSeven');
            $table->string('PalaceHolderEight');
            $table->string('PalaceHolderNine');
            $table->string('PalaceHolderTen');
            $table->json('OrderListArray');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('orders_table');
    }
};
