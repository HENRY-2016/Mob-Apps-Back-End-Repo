<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
// apis
use App\Http\Controllers\BaseApiController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});



Route::get('accounts/login/{phonecustomerLogin}',[BaseApiController::class,'customerLogin']);
Route::post('accounts/register',[BaseApiController::class,'createCustomer']);

// costomer
Route::post('customer/order/post',[BaseApiController::class,'newCustomerOrder']);
Route::get('orders/list/customer/order/details/by/admin/by/id/{id}',[BaseApiController::class,'listAllCustomerOrderDetailsByAdmin']);
Route::get('orders/list/all/customer/orders/by/phone/{phone}',[BaseApiController::class,'listAllCustomerOrders']);
Route::get('orders/list/customer/order/list/array/by/id/{id}',[BaseApiController::class,'listCustomerOrderListArray']);

// Orders
Route::get('orders/list/all/new/orders',[BaseApiController::class,'listAllNewOrders']);
Route::get('orders/list/all/pending/orders',[BaseApiController::class,'listAllPendingOrders']);
Route::get('orders/list/all/cleared/orders',[BaseApiController::class,'listAllClearedOrders']);

// payments
Route::get('payments/list/all/cleared',[BaseApiController::class,'listAllClearedOrderPayments']);
Route::get('payments/list/all/not/cleared',[BaseApiController::class,'listAllNotClearedOrderPayments']);
Route::get('payments/list/all/new/payment',[BaseApiController::class,'listAllNewPayments']);
Route::get('payments/list/all/full/payment',[BaseApiController::class,'listAllFullPayments']);
Route::get('payments/list/all/half/payment',[BaseApiController::class,'listAllHalfPayments']);

// Google play
Route::get('app/googl/play/list/app/statics',[BaseApiController::class,'listAllDashboardGooglePlayAppStatics']);



// dashboard orders
Route::get('dashboard/list/all/cleared/order/payments',[BaseApiController::class,'listAllDashboardClearedOrderPayments']);
Route::get('dashboard/list/all/not/cleared/order/payments',[BaseApiController::class,'listAllDashboardNotClearedOrderPayments']);
Route::get('dashboard/list/all/new/orders',[BaseApiController::class,'listAllDashboardNewOrders']);
Route::get('dashboard/list/all/total/orders',[BaseApiController::class,'listAllDashboardTotalOrders']);

// dashboard payments
Route::get('dashboard/list/all/new/payments',[BaseApiController::class,'listAllDashboardNewPayments']);
Route::get('dashboard/list/all/pending/payments',[BaseApiController::class,'listAllDashboardPendingPayments']);
Route::get('dashboard/list/all/half/payments',[BaseApiController::class,'listAllDashboardHalfPayments']);
Route::get('dashboard/list/all/full/payments',[BaseApiController::class,'listAllDashboardFullPayments']);
Route::get('dashboard/list/all/total/payments',[BaseApiController::class,'listAllDashboardTotalPayments']);




// Products
Route::get('listAllAbout', [BaseApiController::class,'listAllAbout']);
Route::get('listAllSlider', [BaseApiController::class,'listAllSlider']);
Route::get('listAllBabies', [BaseApiController::class,'listAllBabies']);
Route::get('listAllHomeProducts', [BaseApiController::class,'listAllHomeProducts']);
Route::get('listAllOffersProducts', [BaseApiController::class,'listAllOffersProducts']);
Route::get('listAllBlackFridayProducts', [BaseApiController::class,'listAllBlackFridayProducts']);

// Bed Room
Route::get('listAllBedRoomBedsProducts', [BaseApiController::class,'listAllBedRoomBedsProducts']);
Route::get('listAllBedRoomNetsProducts', [BaseApiController::class,'listAllBedRoomNetsProducts']);
Route::get('listAllBedRoomBedCoversProducts', [BaseApiController::class,'listAllBedRoomBedCoversProducts']);
Route::get('listAllBedRoomPillowsProducts', [BaseApiController::class,'listAllBedRoomPillowsProducts']);
Route::get('listAllBedRoomClosetProducts', [BaseApiController::class,'listAllBedRoomClosetProducts']);
Route::get('listAllBedRoomCussionsProducts', [BaseApiController::class,'listAllBedRoomCussionsProducts']);
Route::get('listAllBedRoomShoeRackProducts', [BaseApiController::class,'listAllBedRoomShoeRackProducts']);
Route::get('listAllBedRoomBedSheetsProducts', [BaseApiController::class,'listAllBedRoomBedSheetsProducts']);
Route::get('listAllBedRoomBlanketsProducts', [BaseApiController::class,'listAllBedRoomBlanketsProducts']);
Route::get('listAllBedRoomMattressProducts', [BaseApiController::class,'listAllBedRoomMattressProducts']);
Route::get('listAllBedRoomSandalsProducts', [BaseApiController::class,'listAllBedRoomSandalsProducts']);
Route::get('listAllBedRoomBedSidesProducts', [BaseApiController::class,'listAllBedRoomBedSidesProducts']);
Route::get('listAllBedRoomMirrorsProducts', [BaseApiController::class,'listAllBedRoomMirrorsProducts']);
Route::get('listAllBedRoomNightWareProducts', [BaseApiController::class,'listAllBedRoomNightWareProducts']);
Route::get('listAllBedRoomMattressProtectorsProducts', [BaseApiController::class,'listAllBedRoomMattressProtectorsProducts']);

// Living Room
Route::get('listAllLivingRoomCurtainsProducts', [BaseApiController::class,'listAllLivingRoomCurtainsProducts']);
Route::get('listAllLivingRoomSeatsProducts', [BaseApiController::class,'listAllLivingRoomSeatsProducts']);
Route::get('listAllLivingRoomSideBoardsProducts', [BaseApiController::class,'listAllLivingRoomSideBoardsProducts']);
Route::get('listAllLivingRoomTablesProducts', [BaseApiController::class,'listAllLivingRoomTablesProducts']);
Route::get('listAllLivingRoomCarpetsProducts', [BaseApiController::class,'listAllLivingRoomCarpetsProducts']);
Route::get('listAllLivingRoomIroningBoardProducts', [BaseApiController::class,'listAllLivingRoomIroningBoardProducts']);

// BathRoom
Route::get('listAllBathRoomBathRobsProducts', [BaseApiController::class,'listAllBathRoomBathRobsProducts']);
Route::get('listAllBathRoomTowelsProducts', [BaseApiController::class,'listAllBathRoomTowelsProducts']);
Route::get('listAllBathRoomCurtainsProducts', [BaseApiController::class,'listAllBathRoomCurtainsProducts']);
Route::get('listAllBathRoomDoorMatsProducts', [BaseApiController::class,'listAllBathRoomDoorMatsProducts']);
