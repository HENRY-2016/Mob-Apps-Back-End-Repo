<?php

use Illuminate\Support\Facades\Route;

// resourse controllers
// use App\Http\Controllers\OrdersController;

use App\Http\Controllers\BlackFridayController;
use App\Http\Controllers\CustomersController;
use App\Http\Controllers\OrdersController;
use App\Http\Controllers\OffersController;

use App\Http\Controllers\BedsController;
use App\Http\Controllers\NetsController;
use App\Http\Controllers\BedCoversController;
use App\Http\Controllers\PillowsController;
use App\Http\Controllers\ClosetController;
use App\Http\Controllers\CussionsController;
use App\Http\Controllers\ShoeRackController;
use App\Http\Controllers\BedSheetsController;
use App\Http\Controllers\BlanketsController;
use App\Http\Controllers\MattressController;
use App\Http\Controllers\SandalsController;
use App\Http\Controllers\BedSidesController;
use App\Http\Controllers\MirrorsController;
use App\Http\Controllers\NightWareController;
use App\Http\Controllers\CurtainsController;
use App\Http\Controllers\SeatsController;
use App\Http\Controllers\SideBoardsController;
use App\Http\Controllers\TablesController;
use App\Http\Controllers\CarpetsController;
use App\Http\Controllers\IroningBoardController;
use App\Http\Controllers\BathRobsController;
use App\Http\Controllers\TowelsController;
use App\Http\Controllers\DoorMatsController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\AboutController;
use App\Http\Controllers\SliderController;
use App\Http\Controllers\BathroomCurtainsController;
use App\Http\Controllers\MattressProtectorsController;
use App\Http\Controllers\BabiesController;
// use App\Http\Controllers\PaymentsController;










/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('', function () {return view('MainViews/index');});
Route::get('/login', function () {return view('MainViews/index');});
Route::get('/MainViews/dashboard', function () {return view('MainViews/dashboard');});
Route::get('/dashboard', function () {return view('MainViews/dashboard');});


// Customers
Route::get('/customers/add', function () {return view('customers/add');});

// Orders
Route::get('/orders/new', function () {return view('orders/new');});
Route::get('/orders/pending', function () {return view('orders/pending');});
Route::get('/orders/cleared', function () {return view('orders/cleared');});

// Offers
Route::get('/offers/add', function () {return view('offers/add');});

// home
Route::get('/home/add', function () {return view('home/add');});
// about
Route::get('/about/add', function () {return view('about/add');});
// about
Route::get('/slider/add', function () {return view('slider/add');});
// babies
Route::get('/babies/add', function () {return view('babies/add');});

// Black Friday
Route::get('/blackfriday/add', function () {return view('blackfriday/add');});

// payments
Route::get('/payments/all', function () {return view('payments/all');});
Route::get('/payments/new', function () {return view('payments/new');});
Route::get('/payments/full', function () {return view('payments/full');});
Route::get('/payments/half', function () {return view('payments/half');});
Route::get('/payments/pending', function () {return view('payments/pending');});





// Products ===============
// Bed Rooms
Route::get('/bedroom/beds/add', function () {return view('bedroom/beds/add');});
Route::get('/bedroom/nets/add', function () {return view('bedroom/nets/add');});
Route::get('/bedroom/bedcovers/add', function () {return view('bedroom/bedcovers/add');});
Route::get('/bedroom/pillows/add', function () {return view('bedroom/pillows/add');});
Route::get('/bedroom/closet/add', function () {return view('bedroom/closet/add');});
Route::get('/bedroom/cussions/add', function () {return view('bedroom/cussions/add');});
Route::get('/bedroom/shoerack/add', function () {return view('bedroom/shoerack/add');});
Route::get('/bedroom/bedsheets/add', function () {return view('bedroom/bedsheets/add');});
Route::get('/bedroom/blankets/add', function () {return view('bedroom/blankets/add');});
Route::get('/bedroom/mattress/add', function () {return view('bedroom/mattress/add');});
Route::get('/bedroom/mattressprotectors/add', function () {return view('bedroom/mattressprotectors/add');});
Route::get('/bedroom/sandals/add', function () {return view('bedroom/sandals/add');});
Route::get('/bedroom/bedsides/add', function () {return view('bedroom/bedsides/add');});
Route::get('/bedroom/mirrors/add', function () {return view('bedroom/mirrors/add');});
Route::get('/bedroom/nightware/add', function () {return view('bedroom/nightware/add');});

// Living Room
Route::get('/livingroom/curtains/add', function () {return view('livingroom/curtains/add');});
Route::get('/livingroom/seats/add', function () {return view('livingroom/seats/add');});
Route::get('/livingroom/sideboards/add', function () {return view('livingroom/sideboards/add');});
Route::get('/livingroom/tables/add', function () {return view('livingroom/tables/add');});
Route::get('/livingroom/carpets/add', function () {return view('livingroom/carpets/add');});
Route::get('/livingroom/ironingboard/add', function () {return view('livingroom/ironingboard/add');});

// Bath Rooom
Route::get('/bathroom/bathrobs/add', function () {return view('bathroom/bathrobs/add');});
Route::get('/bathroom/towels/add', function () {return view('bathroom/towels/add');});
Route::get('/bathroom/bathroomcurtains/add', function () {return view('bathroom/bathroomcurtains/add');});
Route::get('/bathroom/doormats/add', function () {return view('bathroom/doormats/add');});

// controllers

Route::resource('blackfridaycrud',BlackFridayController::class);
Route::resource('customerscrud',CustomersController::class);
Route::resource('orderscrud',OrdersController::class);
Route::resource('offerscrud',OffersController::class);
Route::resource('babiescrud',BabiesController::class);


Route::resource('bedscrud',BedsController::class);
Route::resource('netscrud',NetsController::class);
// Route::resource('paymentscrud',PaymentsController::class);
Route::resource('bedscoverscrud',BedCoversController::class);
Route::resource('pillowscrud',PillowsController::class);
Route::resource('closetcrud',ClosetController::class);
Route::resource('cussionscrud',CussionsController::class);
Route::resource('shoerackcrud',ShoeRackController::class);
Route::resource('bedsheetscrud',BedSheetsController::class);
Route::resource('blanketscrud',BlanketsController::class);
Route::resource('mattresscrud',MattressController::class);
Route::resource('sandalscrud',SandalsController::class);
Route::resource('bedsidescrud',BedSidesController::class);
Route::resource('mirrorscrud',MirrorsController::class);
Route::resource('nightwarecrud',NightWareController::class);
Route::resource('curtainscrud',CurtainsController::class);
Route::resource('seatscrud',SeatsController::class);
Route::resource('sideboardscrud',SideBoardsController::class);
Route::resource('tablescrud',TablesController::class);
Route::resource('carpetscrud',CarpetsController::class);
Route::resource('ironingboardcrud',IroningBoardController::class);
Route::resource('bathrobscrud',BathRobsController::class);
Route::resource('towelscrud',TowelsController::class);
Route::resource('doormatscrud',DoorMatsController::class);
Route::resource('homecrud',HomeController::class);
Route::resource('aboutcrud',AboutController::class);
Route::resource('slidercrud',SliderController::class);
Route::resource('bathroomcurtainscrud',BathroomCurtainsController::class);
Route::resource('mattressprotectorscrud',MattressProtectorsController::class);

